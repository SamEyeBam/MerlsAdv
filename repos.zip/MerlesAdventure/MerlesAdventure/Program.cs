﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MerlesAdventure
{
	class MainClass
	{
		static int manyMaps = 10; //n, manual set
		static int[,] mapSizes = new int[manyMaps, 2]; //set size
		static string[][,] Maps = new string[manyMaps][,];//set size
		static bool[] stageDone = new bool[10];
		static Random rnd = new Random();
		static int currentMap = 2; //what room you start in



		public class cPlayer : objectParent
		{
			//public string name;
			public int playerx = 3;
			public int playery = 1;
			//public int level = 1;
			//public int exp = 0;
			public int avlPoints = 3;
			public string[] inventory = new string[10];//remove? TODO


			public cPlayer(string nm)
			{
				name = nm;
				level = 1;
				exp = 0;
				mhealth = 10; //temp
				health = mhealth;
				weapon = "hands";
				attack = 1;
				defence = 1;
				speed = 1;

				inventory[0] = "Encrypted letter";
				inventory[1] = "";
				inventory[2] = "";
				inventory[3] = "";
				inventory[4] = "";
				inventory[5] = "";
				inventory[6] = "";
				inventory[7] = "";
				inventory[8] = "";
				inventory[9] = "";
			}
			public void moveUp()
			{
				if (Maps[currentMap][this.playerx, this.playery - 1] == ".")
				{
					Maps[currentMap][this.playerx, this.playery - 1] = "P";
					Maps[currentMap][this.playerx, this.playery] = ".";
					this.playery -= 1;
				}
			}
			public void moveDown()
			{
				if (Maps[currentMap][this.playerx, this.playery + 1] == ".")
				{
					Maps[currentMap][this.playerx, this.playery + 1] = "P";
					Maps[currentMap][this.playerx, this.playery] = ".";
					this.playery += 1;
				}
			}
			public void moveLeft()
			{
				if (Maps[currentMap][this.playerx - 1, this.playery] == ".")
				{
					Maps[currentMap][this.playerx - 1, this.playery] = "P";
					Maps[currentMap][this.playerx, this.playery] = ".";
					this.playerx -= 1;
				}
			}
			public void moveRight()
			{
				if (Maps[currentMap][this.playerx + 1, this.playery] == ".")
				{
					Maps[currentMap][this.playerx + 1, this.playery] = "P";
					Maps[currentMap][this.playerx, this.playery] = ".";
					this.playerx += 1;
				}
			}
			public void OpenLetter()
			{
				string letterText = System.IO.File.ReadAllText("/home/pc/CS/Test/TestCs/Other/Letter");
				Console.Clear();
				Console.WriteLine(letterText);
			}
			public void disInventory()
			{
				Console.Clear();
				for (int i = 0; i < inventory.Length; i++)
				{
					Console.WriteLine("[{0}]{1}", i, inventory[i]);
				}
			}
			public void SayHi()
			{
				Console.WriteLine("Hi");
			}
		}

		public class objectParent
		{
			public int x;
			public int y;
			public int map;
			public string keyName;
			public string name;
			public string type;
			public bool alive;
			public int mhealth;
			public int health;
			public int attack;
			public int defence;
			public int speed;
			public string weapon;
			public bool hasQuest;
			public bool questCompleted;
			public bool canFight;
			public int level;
			public int exp = 0;
			public bool battle = false;
			public bool questInteract = false;
			public InventorySlot[] slot;
			public int size;
			public bool locked;
			//public string description;
			public virtual void Talk()
			{
			}
			public virtual void Enter(cPlayer p)
			{
			}
			public class InventorySlot
			{
				public string type = "";
				public bool stackable = false;
				public string name = "";
				public int quantity = 0;
				public string description;

				public InventorySlot()
				{
					//Console.WriteLine(this.name);
				}
			}

		}

		public class objectCharacter : objectParent
		{
			public string TalkHello;
			public string TalkOp0;
			public string TalkOp1;
			public string TalkRp0;
			public string TalkRp1;

			public objectCharacter(string nm = "name",bool cnFight = true,bool hsQuest = false, int lvl = 1,
				int mhth = 10,int atk = 1,int def = 1, int spd = 1,string wep = "hands",
				int mp = 1,int xx = 1, int yy = 1,
				string tlkHello = "", 
				string tlkOp0 = "",string tlkOp1 = "",
				string tlkRp0 = "",string tlkRp1 = "")
			{
				name = nm;
				type = "char";
				level = lvl;
				canFight = cnFight;
				hasQuest = hsQuest;
				questCompleted = false;
				alive = true;
				mhealth = mhth;
				health = mhealth;
				attack = atk;
				defence = def;
				speed = spd;
				weapon = wep;
				map = mp;
				x = xx;
				y = yy;

				TalkHello = tlkHello;
				TalkOp0 = tlkOp0;
				TalkOp1 = tlkOp1;
				TalkRp0 = tlkRp0;
				TalkRp1 = tlkRp1;
			}
			public override void Talk()
			{
				Console.WriteLine("[{0}] {1}", name, TalkHello);
				Console.WriteLine("[0] {0}", TalkOp0);
				Console.WriteLine("[1] {0}", TalkOp1);
				if ((hasQuest) && (!questCompleted))
				{
					Console.WriteLine("[2] Quest");
				}
				else if (canFight)
				{
					Console.WriteLine("[2] Fight");
				}
				else if ((hasQuest) && (questCompleted))
				{
					Console.WriteLine("[-] Quest Completed");
				}
				Console.WriteLine("");
				Console.Write("> ");
				string input = Console.ReadLine();
				input.ToLower(); //formats input
				switch (input)
				{
					case "0":
						{
							Console.WriteLine("[{0}] {1}", name, TalkRp0);
							break;
						}
					case "1":
						{
							Console.WriteLine("[{0}] {1}", name, TalkRp1);
							break;
						}
					case "2":
						{
							if ((hasQuest == true) && (!questCompleted))
							{
								this.questInteract = true;
							}
							else if (canFight == true)
							{
								this.battle = true;
							}
							break;
						}
					default:
						{
							Console.WriteLine("Unknown command");
							break;
						}
				}
			}
			public virtual void Speak()
			{
				Console.WriteLine("Hello");
			}
		}

		public class objDoor : objectParent
		{
			public int tox;
			public int toy;
			public int tomap;

			public objDoor(int intx, int inty, int intmap, int inttox, int inttoy, int inttomap, bool lkd = false, string kyName = "")
			{
				type = "door";
				x = intx;
				y = inty;
				map = intmap;
				tox = inttox;
				toy = inttoy;
				tomap = inttomap;
				locked = lkd;
				keyName = kyName;
			}
			public override void Enter(cPlayer p)
			{
				Maps[currentMap][p.playerx, p.playery] = ".";
				currentMap = tomap;
				p.playerx = tox;
				p.playery = toy;
				Maps[currentMap][p.playerx, p.playery] = "P";
			}
		} //Add item needed for unlock

		public class Weapon
		{
			public string name;
			public string type = "wep";
			public int minDmg;
			public int maxDmg;
			//public string description = "";

			public Weapon(string nm, int minD, int maxD)
			{
				name = nm;
				minDmg = minD;
				maxDmg = maxD;
			}
			public int Damage()
			{
				return rnd.Next(minDmg, maxDmg + 1);
			}
		}

		public class Item
		{
			public string name = "";
			public string type = "";
			public bool stackable = false;
			public string description = "";
			public int hthRestore;
			//			public int quantity = 0;

			public Item(string nm, string tpe, bool stck, string desc,int hthRest = 0)
			{
				name = nm;
				type = tpe;
				stackable = stck;
				description = desc;
				hthRestore = hthRest;
			}

		}

		public class InventoryContainer : objectParent
		{
			//public string name;
			//public int size;
			//public bool locked;
			//public InventorySlot[] slot;
			public InventoryContainer(string nm, int sz, int xx, int yy, int intmap, bool lkd = false)
			{
				//constructor
				name = nm;
				type = "cont";
				size = sz;
				x = xx;
				y = yy;
				map = intmap;
				locked = lkd;


				slot = new InventorySlot[size];
				for (int i = 0; i < size; i++)
				{
					slot[i] = new InventorySlot();
				}
			}

			//	public class InventorySlot{
			//		public string name = "";
			//		public string type = "";
			//		public bool stackable = false;
			//		public int quantity = 0;
			//
			//		public InventorySlot(){
			//			//Console.WriteLine(this.name);
			//		}
			//	}

		}

		public class Quest
		{
			public string personName;
			public string questText;
			public string itmNeeded;
			public int itmQuantity;
			public bool started = false;
			public bool completed = false;
			public int expGive;
			public string[] itmGive = new string[5];

			public Quest(string psnName,string qstText, string itmNeed,int itmQnt,int xpGive,
				string itmGive0 = "", string itmGive1 = "", 
				string itmGive2 = "", string itmGive3 = "", string itmGive4 = "")
			{
				personName = psnName;
				questText = qstText;
				itmNeeded = itmNeed;
				itmQuantity = itmQnt;
				expGive = xpGive;
				itmGive[0] = itmGive0;
				itmGive[1] = itmGive1;
				itmGive[2] = itmGive2;
				itmGive[3] = itmGive3;
				itmGive[4] = itmGive4;
				//itmGive = itmGiv;
			}
		}


		public static void Main(string[] args)
		{
			Console.WriteLine("Loading..");
			//-------------START----------------//
			int objSize = 3; //manual set TODO change to objArray.Count;
							 //Random rnd = new Random();

			cPlayer Player = new cPlayer("Merle"); //creates player
			for (int x = 0; x < stageDone.Length; x++)//stages?
			{ //set stages to false
				stageDone[x] = false;
			};

			int tempInt = 0;
			string tempString = "0";
			bool tempBool = false;

			int maxLvl = 15;
			int[] lvlExp = new int[maxLvl];//0 to maxLvl-1
			for (int i = 0; i < maxLvl; i++)
			{
				lvlExp[i] = Convert.ToInt32(Math.Pow(i+1,2))-(i+1)*2+2;//exp needed algarithem
				//Console.WriteLine("{0}: {1}",i+1,lvlExp[i]);
			}

			List<Weapon> weaponData = new List<Weapon>();
			weaponData.Add(new Weapon("hands", 1, 2));
			weaponData.Add(new Weapon("keyboard", 2, 4)); //sams weapon
			weaponData.Add(new Weapon("spoon", 2, 3)); //kitchen
			weaponData.Add(new Weapon("vape", 4, 6));//sams room
			weaponData.Add(new Weapon("god", 99, 99));
			weaponData.Add(new Weapon("beak", 1, 2));//birds weapon
			weaponData.Add(new Weapon("Harsh stare", 3, 5)); //bens weapon
			weaponData.Add(new Weapon("dildo", 1, 5));//bens room
			weaponData.Add(new Weapon("nunchunks", 5, 10));//staceys weapon
			weaponData.Add(new Weapon("plunger", 1, 3)); //bathroom

			List<Item> itemData = new List<Item>();
			itemData.Add(new Item("hands", "wep", false, "These are hands"));
			itemData.Add(new Item("keyboard", "wep", false, "The keyboard has jizz in it"));
			itemData.Add(new Item("spoon", "wep", false, "Just a silver spoon"));
			itemData.Add(new Item("vape", "wep", false, "Mad vape brahh"));
			itemData.Add(new Item("god", "wep", false, "You shouldnt have this"));
			itemData.Add(new Item("Harsh stare", "wep", false, "You shouldnt have this"));
			itemData.Add(new Item("beak", "wep", false, "You shouldnt have this"));
			itemData.Add(new Item("dildo", "wep", false, "Moldy from bens mum"));
			itemData.Add(new Item("nunchucks", "wep", false, "I AM A TURTLE"));
			itemData.Add(new Item("plunger", "wep", false, "You don't want to know where this has been"));

			itemData.Add(new Item("Paper", "itm", true, "Just blank paper"));

			itemData.Add(new Item("Feather", "itm", true, "Feather from some dead bird"));//quest itm
			itemData.Add(new Item("Medal", "itm", true, "Medal for completing something awesome")); //quest itm
			itemData.Add(new Item("Strange Key", "itm", false, "Hmm i wonder what this unlocks"));
			itemData.Add(new Item("Bens Key", "itm", false, "Key to Bens room"));
			itemData.Add(new Item("Sams Key", "itm", false, "Key to Sams room"));
			itemData.Add(new Item("Letter", "itm", false, "[22-11-17]" +
				"Dear Merle This is my gift to you, full of some adventures and some(horrible) jokes." +
				"With that said i think you're amazing and even though i wont know you forever," +
				"i hope you never forget that one time that weird guy who always forgets something made you a game." +
				"From the one and only..." +
				"Sam.."));

			itemData.Add(new Item(nm: "Potion", tpe: "ptn", stck: true, desc: "+10 health",hthRest: 10));

			List<Quest> questData = new List<Quest>();
			questData.Add(new Quest(psnName: "Franzi", qstText: "I need 10 Feathers for an art project", itmNeed: "Feather", itmQnt: 10, xpGive: 5,itmGive0:"Medal", itmGive1:"Strange Key"));
			questData.Add(new Quest("Stacey", "I need 3 Medals to show your worth", "Medal", 3, 1)); 

			List<objectParent> objArray = new List<objectParent>();
			objArray.Add(new objectCharacter(
				nm: "Franzi",
				cnFight:false,
				hsQuest:true, 
				lvl: 5,
				mhth: 30, atk: 4, def: 4, spd: 4,
				wep: "god",
				mp: 4, xx: 2, yy: 5,
				tlkHello: "Oh Morning Merle!",
				tlkOp0: "Morning franzi!", tlkOp1: "How are you?",
				tlkRp0: "Glad to see you so happy :)", tlkRp1: "Im great!"));
			objArray.Add(new objectCharacter(
				nm: "Ben",
				cnFight: true,
				hsQuest: false,
				lvl: 4,
				mhth: 25, atk: 10, def: 1, spd: 4,
				wep: "Harsh stare",
				mp: 3,
				xx: 3,
				yy: 1,
				tlkHello: "Oh hello Merle",
				tlkOp0: "Morning Ben!", tlkOp1: "Fuck your birds",
				tlkRp0: "Ha Stacey wake you up with a little bit of hmm hmm", tlkRp1: "Well thats fucking rude"));
			objArray.Add(new objectCharacter(
				nm: "Sam",
				cnFight: true,
				hsQuest: false,
				lvl: 6,
				mhth: 40, atk: 4, def: 8, spd: 6,
				wep: "keyboard",
				mp: 4,
				xx: 12,
				yy: 2,
				tlkHello: "Morning Merle!",
				tlkOp0: "Morning Sam!", tlkOp1: "Fuck you!",
				tlkRp0: "Done the dishes too btw :)", tlkRp1: "Hahaha fuck you too"));
			objArray.Add(new objectCharacter(
				nm: "Birds",
				cnFight: true,
				hsQuest: false,
				lvl: 2, 
				mhth: 15, atk: 2, def: 1, spd: 2, 
				wep: "beak",
				mp: 5, 
				xx: 9, 
				yy: 3,
				tlkHello: "Chirp chirp",
				tlkOp0: "Morning Birds!", tlkOp1: "Fuck you birds",
				tlkRp0: "Chirp chirp chirp", tlkRp1: "Chirp.."));
			objArray.Add(new objectCharacter(
				nm: "Stacey",
				cnFight: true, 
				hsQuest: true,
				lvl: 8,
				mhth: 60,
				atk: 10, 
				def: 8, 
				spd: 9,
				wep: "vape",
				mp: 6, xx: 3, yy: 1,
				tlkHello: "[BOSS]Complete my quest to show youre worthy of a fight!",
				tlkOp0: "Morning Stacey!", tlkOp1: "How do i get the Medals?",
				tlkRp0: "... Morning Merle", tlkRp1: "One from Ben, one from Sam, one from Franzi"));
			objArray.Add(new objDoor(6, 1, 2, 1, 1, 3));//to upstairs main
			objArray.Add(new objDoor(0, 1, 3, 5, 1, 2));//to staceys room
			objArray.Add(new objDoor(4, 3, 3, 7, 4, 4));//to downstairs
			objArray.Add(new objDoor(5, 3, 3, 7, 4, 4));//to downstairs
			objArray.Add(new objDoor(7, 3, 4, 4, 2, 3));//to upstairs
			objArray.Add(new objDoor(5, 0, 4, 8, 3, 5));//to outside
			objArray.Add(new objDoor(8, 4, 5, 5, 1, 4));//from outside
			objArray.Add(new objDoor(4, 0, 3, 7, 3, 7));//to bathroom
			objArray.Add(new objDoor(7, 4, 7, 4, 1, 3));//from bathroom
			objArray.Add(new objDoor(6, 1, 3, 1, 2, inttomap: 8,lkd: true, kyName: "Bens Key"));//to Bens room
			objArray.Add(new objDoor(0, 2, 8, 5, 1, 3));//from Bens room
			objArray.Add(new objDoor(intx: 6, inty: 2, intmap: 3, inttox: 1, inttoy: 1, inttomap: 9,lkd:true,kyName:"Sams Key"));//to Sams room
			objArray.Add(new objDoor(0, 1, 9, 5, 2, 3));//from Sams room TODO
			objArray.Add(new objDoor(intx: 6, inty: 1, intmap: 4, inttox: 1, inttoy: 1, inttomap: 6,lkd: true,kyName: "Strange Key"));//to mini room
			objArray.Add(new objDoor(intx: 0, inty: 1, intmap: 6, inttox: 5, inttoy: 1, inttomap: 4));//from mini room
			objArray.Add(new InventoryContainer("Inventory", 10, 0, 0, 0));
			objArray.Add(new InventoryContainer(nm: "testInv", sz: 5, xx: 1, yy: 3, intmap: 3));
			objArray.Add(new InventoryContainer(nm: "Bathroom Cupboard", sz: 5, xx: 7, yy: 2, intmap: 7));
			objArray.Add(new InventoryContainer(nm: "Bens Cupboard", sz: 5, xx: 1, yy: 1, intmap: 8));
			objArray.Add(new InventoryContainer(nm: "Sams Draw", sz: 4, xx: 1, yy: 3, intmap: 9));
			objArray.Add(new InventoryContainer(nm: "Sams Cupboard", sz: 5, xx: 4, yy: 0, intmap: 9));
			objArray.Add(new InventoryContainer(nm: "Kitchen Cupboard", sz: 5, xx: 4, yy: 6, intmap: 4));
			objArray.Add(new InventoryContainer(nm: "CONGRATS", sz: 1, xx: 3, yy: 3, intmap: 6));

			//ContainerItemAdd(objId("Inventory"), "Strange Key");
			ContainerItemAdd(objId("Inventory"), "Potion", 2);

			ContainerItemAdd(objId("Bens Cupboard"), "dildo");
			ContainerItemAdd(objId("Bens Cupboard"), "Paper", 2);
			ContainerItemAdd(objId("Bens Cupboard"), "Potion", 3);

			ContainerItemAdd(objId("Sams Draw"), "Potion", 3);
			ContainerItemAdd(objId("Sams Draw"), "vape");
			ContainerItemAdd(objId("Sams Cupboard"), "Potion", 2);

			ContainerItemAdd(objId("Bathroom Cupboard"), "plunger");
			ContainerItemAdd(objId("Bathroom Cupboard"), "Potion");

			ContainerItemAdd(objId("Kitchen Cupboard"), "Potion", 2);
			ContainerItemAdd(objId("Kitchen Cupboard"), "spoon");

			ContainerItemAdd(objId("CONGRATS"), "Letter"); //message to merle

			void objSizeInit()
			{
				objSize = 0;
				foreach (var i in objArray)
				{
					objSize += 1;
				}
			}
			objSizeInit();


			//Load in map files to Maps[][,] array
			void loadInMaps()
			{
				string location = @"C:\Users\PC\source\repos\MerlesAdventure\MerlesAdventure\Maps";
				//string location = @"Maps";
				//location = Console.ReadLine();
				for (int x = 0; x <= manyMaps - 1; x++)
				{
					string loc = location + "/Map" + System.Convert.ToString(x) +".txt";
					string fileContents = System.IO.File.ReadAllText(loc);
					fileContents = fileContents.Replace(System.Environment.NewLine, ""); //removes NL

					mapSizes[x, 0] = System.Convert.ToInt32(fileContents.Substring(0, 2)); //places in the x
					mapSizes[x, 1] = System.Convert.ToInt32(fileContents.Substring(2, 2)); //places in the y

					Maps[x] = new string[mapSizes[x, 0], mapSizes[x, 1]];//initialze map (sets the array size)
					int tempPosCounter = 4;
					for (int y = 0; y < mapSizes[x, 1]; y++)
					{ //y
						for (int j = 0; j < mapSizes[x, 0]; j++)
						{ //x
							Maps[x][j, y] = System.Convert.ToString(fileContents[tempPosCounter]); //places char into map
							tempPosCounter += 1;
						}
						//next loop
					}
				}
			}
			//Display Map
			void displayMap(int x)
			{
				Console.Clear();
				for (int y = 0; y < mapSizes[x, 1]; y++)
				{ //y
					for (int j = 0; j < mapSizes[x, 0]; j++)
					{ //x
						Console.Write(Maps[x][j, y]);
						/*if ((y == 0) && (j == (mapSizes[x,0]) - 1)){
							Console.Write(" [{0},{1}]", Player.playerx,Player.playery);
						}*/
					}
					Console.WriteLine("");
				}
				//health
				Console.SetCursorPosition(mapSizes[x, 0], 0);
				Console.Write(" Hth:[{0}/{1}]", Player.health, Player.mhealth);
				//level
				Console.SetCursorPosition(mapSizes[x, 0], 1);
				Console.Write(" Lvl:{0}[{1}/{2}]", Player.level, Player.exp, lvlExp[Player.level]);
				//attack
				Console.SetCursorPosition(mapSizes[x, 0], 2);
				var wepTmp = weaponData.First(item => item.name == Player.weapon);
				Console.Write(" Atk:{0}+[{1}-{2}]", Player.attack, wepTmp.minDmg, wepTmp.maxDmg); //TODO
				//defence
				Console.SetCursorPosition(mapSizes[x, 0], 3);
				Console.Write(" Def:{0}", Player.defence);
				//speed
				Console.SetCursorPosition(mapSizes[x, 0], 4);
				Console.Write(" Spd:{0}", Player.speed);
				//weapon
				Console.SetCursorPosition(mapSizes[x, 0], 5);
				Console.Write(" Wep:[{0}]", Player.weapon);
				//x,y
				Console.SetCursorPosition(mapSizes[x, 0], 6);
				Console.Write(" Pos:[{0},{1}]", Player.playerx, Player.playery);
				//set x,y under map
				Console.SetCursorPosition(0, mapSizes[x, 1]);
			}

			void envInteract(int xx, int yy)
			{ // doesnt check for current map
				for (int j = 0; j < objSize; j++)
				{
					if (objArray[j].map == currentMap)
					{
						if ((Player.playerx + xx == objArray[j].x) && (Player.playery + yy == objArray[j].y))
						{ //check player x + direction = objects y

							if ((objArray[j].type == "char")&&(objArray[j].alive == true))
							{
								objArray[j].Talk();
								if (objArray[j].battle == true)
								{
									Battle(j);
									break;
								}
								else if (objArray[j].questInteract == true)
								{
									//add method ui for quest
									questInteractUI(objArray[j].name);
									displayMap(currentMap);
									break;
								}
							}
							else if (objArray[j].type == "door")
							{
								if (objArray[j].locked == true)
								{
									doorUI(j);
									displayMap(currentMap);
									break;
								}
								else
								{
									objArray[j].Enter(Player);
									displayMap(currentMap);
									break;
								}
							}
							else if (objArray[j].type == "cont")
							{
								ContainerUI(j);
								break;
							}
						}
					}
				}
			}

			int InvId()
			{
				return objArray.FindIndex(item => item.name == "Inventory");
			}

			int objId(string nm)
			{
				return objArray.FindIndex(item => item.name == nm);
			}

			void DataAddItem() { }//impliment weapon

			void DataAddDoor(int frmx, int frmy, int frmmap, int tox, int toy, int tomap, bool lkd = false, string kyName = "")
			{
				objArray.Add(new objDoor(frmx,frmy, frmmap, tox, toy, frmmap, lkd, kyName));
			}

			void DataAddCharacter() { }//impliment quest

			void DataAddContainer(string name, int sz, int xx, int yy, int intmap, string[] itemsAdd) {

				objArray.Add(new InventoryContainer(name, sz, xx, yy, intmap));

				if ((itemsAdd != null) ||(itemsAdd[0] == ""))
				{
					foreach (var item in itemsAdd)
					{
						ContainerItemAdd(objId(name), item);
					}
				}


			}//impliment items to add
			 //PrintArray(new int[] { 1, 3, 5, 7, 9 });

			void Death()
			{
				Player.health = 0;
			}

			void ckLevelUp()
			{ 
				while (Player.exp >= lvlExp[Player.level])
				{
					Player.health = Player.mhealth;
					Player.exp -= lvlExp[Player.level];
					Player.level++;
					Player.avlPoints += 3;
					Console.WriteLine("Leveled up");
				}
			}

			void giveExp(int amt)
			{
				Player.exp += amt;
				ckLevelUp();
			}

			void charDeathMisc(int x)
			{
				//birds char
				if (objArray[x].name == "Birds")
				{
					charRevive("Birds");
					tempInt = rnd.Next(1, 2 + 1);
					ContainerItemAdd(InvId(), "Feather", tempInt);
					Console.WriteLine("+'Feather'[{0}]",tempInt);
					if (rnd.Next(1,3+1) == 2)
					{
						ContainerItemAdd(InvId(), "Potion");
						Console.WriteLine("+'Potion'");
					}
				}
				else if (objArray[x].name == "Ben")
				{
					ContainerItemAdd(InvId(), "Medal");
					Console.WriteLine("+'Medal'");
					ContainerItemAdd(InvId(), "Bens Key");
					Console.WriteLine("+'Bens Key'");
				}
				else if (objArray[x].name == "Sam")
				{
					ContainerItemAdd(InvId(), "Medal");
					Console.WriteLine("+'Medal'");
					ContainerItemAdd(InvId(), "Sams Key");
					Console.WriteLine("+'Sams Key'");
				}
			}

			void addStat(string stat,int nb = 1)
			{
				if (Player.avlPoints >= nb)
				{
					if (stat == "hth")
					{
						Player.mhealth += 5 * nb;
						Player.health = Player.mhealth;
					}
					else if (stat == "atk")
					{
						Player.attack += nb;
					}
					else if (stat == "def")
					{
						Player.defence += nb;
					}
					else if (stat == "spd")
					{
						Player.speed += nb;
					}
					else
					{
						Console.WriteLine("Error addStat");
						Console.ReadLine();
					}
					Player.avlPoints -= nb;

				}
				else
				{
					Console.WriteLine("Not enough points");
					Console.WriteLine("Press Enter to continue");
					Console.ReadLine();
				}
			}

			void statsUI()
			{
				bool Done = false;
				bool showNb = false; //for indexing
				//draw
				void Draw()
				{
					string nbText = ""; // text for indexing
					int nmb = 0;
					void nmbUpdate(){ //If upgrade stat then show which index
						if (showNb == true)
						{
							nmb++; //each time its called the index ++
							nbText = "[" + nmb + "]";
						}
						else
						{
							nbText = "";
						}
					}
					nmbUpdate();
					Console.Clear();
					Console.WriteLine("Stats:");
					//level
					Console.WriteLine("Lvl:{0}[{1}/{2}]", Player.level, Player.exp, lvlExp[Player.level]);
					//available points
					Console.WriteLine("Available Points: {0}", Player.avlPoints);
					Console.WriteLine("");
					//health
					Console.WriteLine("{0}Hth:[{1}/{2}]" ,nbText, Player.health, Player.mhealth);
					nmbUpdate();
					//attack
					var wepTmp = weaponData.First(item => item.name == Player.weapon);
					Console.WriteLine("{0}Atk:{1}[{2}-{3}]", nbText, Player.attack, wepTmp.minDmg, wepTmp.maxDmg);
					nmbUpdate();
					//defence								  
					Console.WriteLine("{0}Def:{1}", nbText, Player.defence);
					nmbUpdate();
					//speed
					Console.WriteLine("{0}Spd:{1}", nbText, Player.speed);
					nmbUpdate();
					//weapon
					Console.WriteLine("Wep:[{0}]", Player.weapon);

					if (showNb == true)
					{
						Console.WriteLine("");
						Console.WriteLine("[9]Leave");
					}
				}
				//user input
				void usrInput()
				{
					Console.WriteLine("");
					Console.WriteLine("[0]Upgrade Stats");
					Console.WriteLine("[9]Leave");
					Console.Write("> ");
					string input = Console.ReadLine();
					bool statAddDone = false;
					switch (input)
					{
						case "0":
							{
								showNb = true;
								Draw();
								//Console.WriteLine("");
								//Console.WriteLine("");
								//Console.WriteLine("[9] Leave");
								while (statAddDone == false)
								{
									Console.Write("stat> ");
									string tempInput = Console.ReadLine();
									tempBool = Int32.TryParse(tempInput, out tempInt);
									if (tempBool == true)
									{
										if (tempInt == 1)
										{
											addStat("hth");
										}
										else if (tempInt == 2)
										{
											addStat("atk");
										}
										else if (tempInt == 3)
										{
											addStat("def");
										}
										else if (tempInt == 4)
										{
											addStat("spd");
										}
										else if (tempInt == 9)
										{
											statAddDone = true;
										}
										else
										{
											Console.WriteLine("incorrect input");
											Console.WriteLine("Press Enter to continue..");
											Console.ReadLine();
										}
										Draw();
									}
									else
									{
										//input not a number
										Console.WriteLine("incorrect input");
										Console.WriteLine("Press Enter to continue..");
										Console.ReadLine();
										Draw();
									}
								}
								showNb = false;
								break;
							}
						case "9":
							{
								Done = true;
								break;
							}
						default:
							{
								Console.WriteLine("Unknown Command");
								break;
							}
					}

				}
				//run
				while (Done == false)
				{
					Draw();
					usrInput();

				}
			}

			void doorUI(int doorIndex)
			{
				bool done = false;

				//check if door is locked
				void draw(){
					//write door is locked
					clearScreen(mapYY(), mapYY()+10);
					Console.SetCursorPosition(0, mapYY());
					Console.WriteLine("This door is locked (maybe you can find a key)");
					
				}

				void ckForKey()
				{
					tempInt = ContainerItemFind(objArray[doorIndex].keyName);
					if (tempInt != -1)
					{
						//ContainerItemDestroy(InvId(), tempInt); //destroys the key
						Console.WriteLine("Door Unlocked!");
						objArray[doorIndex].locked = false;
						done = true;
						Console.WriteLine("Press ENTER to continue..");
						Console.Read();
					}
					else
					{
						Console.WriteLine("You dont have the right key");
						Console.WriteLine("Press ENTER to continue..");
						Console.Read();
					}
				}

				void usrInput()
				{
					Console.SetCursorPosition(0, mapYY() + 2);
					Console.WriteLine("[0]Unlock");
					Console.WriteLine("[1]Leave");
					Console.Write("> ");
					string input = Console.ReadLine();
					switch (input)
					{
						case "0":
							{
								ckForKey();
								break;
							}
						case "1":
							{
								done = true;
								break;
							}
					}
				}
				while (!done)
				{
					draw();
					usrInput();
				}
			}

			void charRevive(string nm)
			{
				int charInd = objArray.FindIndex(item => item.name == nm);
				Maps[objArray[charInd].map][objArray[charInd].x, objArray[charInd].y] = "c";
				objArray[charInd].alive = true;
				objArray[charInd].health = objArray[charInd].mhealth;
			}

			int mapYY()
			{
				return mapSizes[currentMap, 1]+1;
			}

			void clearScreen(int iFrom, int iTo)
			{
				for (int n = iFrom; n <= iTo; n++)
				{
					Console.SetCursorPosition(0, n);
					for (int i = 0; i < Console.WindowWidth; i++)
					{
						Console.Write(" ");
					}
				}
			}

			void Battle(int j)
			{
				objectParent other = objArray[j];
				int disy = 7;
				bool canAttack = false;
				Console.Clear();
				objectParent[] Person = new objectParent[2] { Player, other };
				//clear area
				void clearMid(int iFrom, int iTo)
				{

					for (int n = iFrom; n <= iTo; n++)
					{
						Console.SetCursorPosition(0, n);
						for (int i = 0; i < Console.WindowWidth; i++)
						{
							Console.Write(" ");
						}
					}
				}
				//health bar
				void HealthBar(int xx, int yy, bool bPlayer)
				{
					//Console.WriteLine(Person[0].name); remove
					if (bPlayer == true)
					{
						tempInt = (Person[0].health * 10) / Person[0].mhealth; //never let the number become decimal
					}
					else
					{
						tempInt = (other.health * 10) / other.mhealth;
					}
					Console.SetCursorPosition(xx, yy);
					Console.Write("[");
					for (int i = 0; i < tempInt; i++)
					{
						Console.Write("#");//HealthBar!!
					}
					if (tempInt<= 0)
					{
						tempInt = 0;
					}
					for (int i = 0; i < 10 - tempInt; i++)
					{
						Console.Write("-");
					}
					Console.Write("]");
					Console.SetCursorPosition(xx, yy + 1);

				}
				//draw
				void draw()
				{
					int drwx = 13;
					clearMid(0, disy - 1);
					tempInt = (Player.health * 10) / Player.mhealth; //never let the number become decimal
					var wepTmp = weaponData.First(item => item.name == Person[0].weapon);
					Console.SetCursorPosition(0, 0);
					Console.WriteLine("[{0}]", Player.name);
					HealthBar(0, 1, true);
					Console.WriteLine("Hth:{0}/{1}", Player.health, Player.mhealth);
					Console.WriteLine("Wep:{0}", Player.weapon);
					Console.WriteLine("Atk:{0}+[{1}-{2}]", Player.attack, wepTmp.minDmg, wepTmp.maxDmg);
					Console.WriteLine("Def:{0}", Person[0].defence);
					Console.WriteLine("Spd:{0}", Person[0].speed);


					Console.SetCursorPosition(13, 0); //enemy draw
					wepTmp = weaponData.First(item => item.name == Person[1].weapon);
					Console.Write("| [{0}]", Person[1].name);
					HealthBar(13, 1, false);
					Console.SetCursorPosition(13, 2);
					Console.WriteLine("| Hth:{0}/{1}", Person[1].health, Person[1].mhealth);
					Console.SetCursorPosition(13, 3);
					Console.WriteLine("| Wep:{0}", Person[1].weapon);
					Console.SetCursorPosition(13, 4);
					Console.WriteLine("| Atk:{0}+[{1}-{2}]", Person[1].attack, wepTmp.minDmg, wepTmp.maxDmg);
					Console.SetCursorPosition(drwx, 5);
					Console.WriteLine("| Def:{0}", Person[1].defence);
					Console.SetCursorPosition(drwx, 6);
					Console.WriteLine("| Spd:{0}", Person[1].speed);
				}
				//attack single hit
				void atkRound()
				{
					void personAttack(int l, int t)
					{ //0 for player 1 for other, t for disy placement

						if (rnd.Next(0, 100) > 79)
						{
							canAttack = true;
						}

						if (canAttack == true)
						{
							int wepDm = weaponData.First(item => item.name == Person[l].weapon).Damage();
							int totalDamage = Person[0 + l].attack + wepDm - Person[1 - l].defence; //damage equasion
							if (totalDamage >= 0)
							{ //untested Done
								Person[1 - l].health -= totalDamage; //TODO if defence is high enough, damage adds health
							}
							draw();
							Console.SetCursorPosition(0, disy + 1 + t);
							Console.WriteLine("[{0}]Hit {1} with [{2}] for {3} damage",
								Person[l].name, Person[1 - l].name, Person[l].weapon, totalDamage);
						}
						else
						{
							Console.SetCursorPosition(0, disy + 1 + t);
							Console.WriteLine("[{0}]Missed!", Person[l].name);
						}
					}
					//check if Players is dead
					bool ckIfDead()
					{
						Console.SetCursorPosition(0, disy + 3);
						if (Person[0].health <= 0)
						{
							Console.WriteLine("You Died!"); //---Player dies---
							other.battle = false; //TODO remove this
							Death();
							Person[1].health = Person[1].mhealth;
							Console.SetCursorPosition(0, disy + 7);
							return true;
						}
						else if (Person[1].health <= 0)
						{
							Console.WriteLine("You killed Him/Her!"); //---other dies---
							other.battle = false;
							Maps[currentMap][other.x, other.y] = ".";
							other.alive = false; 
							Console.SetCursorPosition(0, disy + 8);
							Console.WriteLine("You gained {0} EXP!", Person[1].level * 2);
							Person[0].exp += Person[1].level * 2;
							ckLevelUp();
							charDeathMisc(objId(Person[1].name));
							Console.Write("Press any ENTER to continue..");
							Console.Read();
							return true;
						}
						else
						{
							return false;
						}
					}

					//Determine who attacks first
					int firstToAtk;
					if (Player.speed >= other.speed)
					{
						firstToAtk = 0;
					}
					else
					{
						firstToAtk = 1;
					}
					personAttack(0 + firstToAtk, 0);// person, disy placement
					tempBool = ckIfDead(); //checks if person killed other, if not then runs method for other person to hit
					if (!tempBool)
					{
						personAttack(1 - firstToAtk, 1);
						ckIfDead();
					}
				}
				//input
				void usrInput()
				{
					Console.SetCursorPosition(0, disy + 4);
					Console.WriteLine("[0]Attack");
					Console.WriteLine("[1]Block"); //TODO
					Console.WriteLine("[2]Potion"); //TODO
					Console.Write("> ");
					string input = Console.ReadLine();
					clearMid(disy, disy + 3); //battle narration
					clearMid(disy + 7, disy + 7); //command line
					switch (input)
					{
						case "0":
							{
								atkRound();
								break;
							}
						case "1":
							{

								break;
							}
						default:
							{
								Console.WriteLine("Unknown Command");
								break;
							}
					}
				}
				//run
				while (other.battle)
				{
					draw();
					usrInput();

				}
			}

			void ContainerItemAdd(int C, string itemNm, int amt = 1)
			{
				bool done = false;
				//C = container, itemNm reference item database, amt = quantity
				if (done == false)
				{
					for (int i = 0; i < objArray[C].size; i++)
					{
						if ((objArray[C].slot[i].name == itemNm)
						&& (objArray[C].slot[i].stackable == true))
						{ //if ywou already have the item

							objArray[C].slot[i].quantity += amt;
							done = true;
							break;
						}

					}
				}
				if (done == false)
				{
					for (int i = 0; i < objArray[C].size; i++)
					{
						if (objArray[C].slot[i].name == "")
						{

							int itemId = itemData.FindIndex(item => item.name == itemNm);

							objArray[C].slot[i].name = itemData[itemId].name;
							objArray[C].slot[i].type = itemData[itemId].type;
							objArray[C].slot[i].stackable = itemData[itemId].stackable;
							objArray[C].slot[i].quantity = amt;
							objArray[C].slot[i].description = itemData[itemId].description;

							break;
						}
					}
				}

			}//Add if item not stackable add more of them

			void ContainerItemDestroy(int C, int ind, bool all = true, int amt = 1)
			{
				if ((all == false)&&(objArray[C].slot[ind].quantity > amt))
				{
					objArray[C].slot[ind].quantity -= amt;
				}
				else
				{
					objArray[C].slot[ind].name = "";
					objArray[C].slot[ind].type = "";
					objArray[C].slot[ind].stackable = false;
					objArray[C].slot[ind].quantity = 0;
					objArray[C].slot[ind].description = "";
				}
			}

			void ContainerDisplay(int C)
			{
				//C = container
				//Console.Clear();
				for (int i = 0; i < objArray[C].size; i++)
				{
					Console.Write("[{0}] {1}", i + 1, objArray[C].slot[i].name);

					if (objArray[C].slot[i].stackable == true)
					{
						Console.Write(" ({0})", objArray[C].slot[i].quantity);
					}
					Console.WriteLine("");

				}
			}

			void ContainerSort(int C)
			{
				//C = container
				void Swap(int fst, int snd)
				{
					//name
					tempString = objArray[C].slot[fst].name;
					objArray[C].slot[fst].name = objArray[C].slot[snd].name;
					objArray[C].slot[snd].name = tempString;
					//type
					tempString = objArray[C].slot[fst].type;
					objArray[C].slot[fst].type = objArray[C].slot[snd].type;
					objArray[C].slot[snd].type = tempString;
					//stackable
					tempBool = objArray[C].slot[fst].stackable;
					objArray[C].slot[fst].stackable = objArray[C].slot[snd].stackable;
					objArray[C].slot[snd].stackable = tempBool;
					//quantity
					tempInt = objArray[C].slot[fst].quantity;
					objArray[C].slot[fst].quantity = objArray[C].slot[snd].quantity;
					objArray[C].slot[snd].quantity = tempInt;
					//description
					tempString = objArray[C].slot[fst].description;
					objArray[C].slot[fst].description = objArray[C].slot[snd].description;
					objArray[C].slot[snd].description = tempString;
				}

				for (int j = 0; j < objArray[C].size; j++)
				{
					for (int i = 0; i < objArray[C].size - 1; i++)
					{
						if (objArray[C].slot[i].name == "")
						{
							Swap(i, i + 1);
						}
					}
				}

			}

			void ContainerItemTransfer(bool T, int C, int fromInd)
			{
				//T = true if from player inv to container, C = container, fromInd = index
				int otherC;
				if (T == true)
				{ //orentates which C is main and which is other
					otherC = C;
					C = objArray.FindIndex(item => item.name == "Inventory");
				}
				else
				{
					otherC = objArray.FindIndex(item => item.name == "Inventory");
				}

				if ((fromInd >= 0)
				&& (fromInd < objArray[C].size)
				&& (objArray[C].slot[fromInd].name != ""))
				{ //removes user error and cant transfer nothing
					for (int i = 0; i < objArray[otherC].size; i++)
					{ //search through each slot for free space
						if (objArray[otherC].slot[i].name == "")
						{ //if its free
							string itemNm = objArray[C].slot[fromInd].name; //name and quantity needed for
							int itemAmt = objArray[C].slot[fromInd].quantity;//item add
							ContainerItemAdd(otherC, itemNm, itemAmt); //adds item to container
							ContainerItemDestroy(C, fromInd); //removes item form org cont
							ContainerSort(C); //sorts cont after item removed
							break;
						}
					}
				}

			}

			string ContainerItemInspect(int C, int ind)
			{
				if ((ind >= 0) && (ind < objArray[C].size))
				{
					Console.WriteLine("[{0}] {1}", objArray[C].slot[ind].name, objArray[C].slot[ind].description);
					return objArray[C].slot[ind].description;
				}
				else
				{
					return "";
				}
			}

			int ContainerItemFind(string itemName)
			{
				int invInd = objArray.FindIndex(item => item.name == "Inventory");

				for (int i = 0; i < objArray[invInd].size; i++)
				{
					if (objArray[invInd].slot[i].name == itemName)
					{
						return i;
					}
				}


				return -1;
			}

			void questInteractUI(string psnName)
			{
				int qst = questData.FindIndex(item => item.personName == psnName);
				int psn = objArray.FindIndex(item => item.name == psnName);
				int invInd = objArray.FindIndex(item => item.name == "Inventory");
				void clear()
				{
					clearScreen(mapYY(), mapYY() + 7);
					Console.SetCursorPosition(0, mapYY());
					Console.WriteLine("[{0}] {1}",psnName ,questData[qst].questText);
				}

				void ckQuestComplete()
				{
					int invSlot = ContainerItemFind(questData[qst].itmNeeded);//see if you have the item needed
					if (invSlot != -1)//checks to see if the item was found
					{
						if (objArray[invInd].slot[invSlot].quantity >= questData[qst].itmQuantity)//checks if you had enough
						{
							Console.SetCursorPosition(0, mapYY() + 5);
							//remove item from inv
							ContainerItemDestroy(invInd, invSlot);
							//give exp
							Console.WriteLine("+{0} EXP!", questData[qst].expGive);
							giveExp(questData[qst].expGive);
							Console.WriteLine("");
							//give items to inv
							foreach (var item in questData[qst].itmGive)
							{
								if (item != "")
								{
									ContainerItemAdd(invInd, item);
									Console.WriteLine("+ '{0}'", item);
								}
							}
							//quest.complete = true
							questData[qst].completed = true;
							objArray[psn].questCompleted = true;

							Console.Read();
							objArray[psn].questInteract = false;
						}
					}
				}
				//input
				void usrInput()
				{
					if (questData[qst].started == false)
					{
						Console.WriteLine("[0]Accept");
						Console.WriteLine("[1]Decline");
						Console.Write("> ");
						tempString = Console.ReadLine();
						Int32.TryParse(tempString, out tempInt);
						if (tempInt == 0)
						{
							questData[qst].started = true;
						}
						else if (tempInt == 1)
						{
							objArray[psn].questInteract = false;
						}
					}
					else if (questData[qst].started == true)
					{
						Console.WriteLine("[0]Complete");
						Console.WriteLine("[1]Leave");
						Console.Write("> ");
						tempString = Console.ReadLine();
						Int32.TryParse(tempString, out tempInt);

						if (tempInt == 0)
						{
							ckQuestComplete();
						}
						else if (tempInt == 1)
						{
							objArray[psn].questInteract = false;
						}
					}
				}
				//run
				while (objArray[psn].questInteract == true)
				{
					clear();
					usrInput();
				}
			}

			void ItemUse(string itemm) //health potions only so far UNTESTED
			{
				int itmInd = itemData.FindIndex(item => item.name == itemm); //finds item index of item
				int invIndex = ContainerItemFind(itemm); //checks if you have said item

				if ((itmInd >= 0)&&(invIndex != -1)) //item found in itemData and in your inventory
				{
					if (itemData[itmInd].type == "ptn")
					{
						Player.health += itemData[itmInd].hthRestore;
						if (Player.health > Player.mhealth)
						{
							Player.health = Player.mhealth;
						}
						ContainerItemDestroy(InvId(),invIndex,false,1);
						Console.WriteLine("+{0} Health", itemData[itmInd].hthRestore);
					}

				}
			}

			void ItemEquipt(string wep, int ind)
			{
				tempInt = itemData.FindIndex(item => item.name == wep); //finds item index of weapon
				if ((ind >= 0) && (tempInt >= 0) && (itemData[tempInt].type == "wep"))
				{
					int userInvInd = objArray.FindIndex(item => item.name == "Inventory");
					//store user weapon name temp
					tempString = Player.weapon;
					//equipt item
					Player.weapon = wep;
					//destroy inventory slot
					ContainerItemDestroy(userInvInd, ind);
					//add item of weapon temp
					ContainerItemAdd(userInvInd, tempString);
				}
			}

			void InventoryUI()
			{
				bool done = false;
				int userInvInd = objArray.FindIndex(item => item.name == "Inventory");
				//draw
				void Draw()
				{
					Console.WriteLine(objArray[userInvInd].name);
					ContainerDisplay(userInvInd);
					Console.WriteLine("");
				}
				//input
				void usrInput()
				{
					//					Console.WriteLine("");
					//					Console.WriteLine("");
					//					Console.WriteLine("");
					Console.WriteLine("[0]Inspect");
					Console.WriteLine("[1]Equipt");
					Console.WriteLine("[2]Use");
					Console.WriteLine("[3]Destroy");
					Console.WriteLine("[4]Leave");
					Console.Write("> ");
					string input = Console.ReadLine();
					switch (input)
					{
						case "0":
							{
								Console.Write("slot> ");
								string tempInput = Console.ReadLine();
								tempBool = Int32.TryParse(tempInput, out tempInt);
								if (tempBool == true)
								{
									tempInt -= 1;
									//								Console.SetCursorPosition(0,12);
									ContainerItemInspect(userInvInd, tempInt);
									//								Console.SetCursorPosition(0,16);
									Console.ReadLine();

								}
								break;
							}
						case "1":
							{
								Console.Write("slot> ");
								string tempInput = Console.ReadLine();
								tempBool = Int32.TryParse(tempInput, out tempInt);
								if (tempBool == true)
								{
									tempInt -= 1;
									tempString = objArray[userInvInd].slot[tempInt].name;
									ItemEquipt(tempString, tempInt);
								}
								break;
							}
						case "2":
							{
								Console.Write("slot> ");
								string tempInput = Console.ReadLine();
								tempBool = Int32.TryParse(tempInput, out tempInt);
								if (tempBool == true)
								{
									tempInt -= 1;
									ItemUse(objArray[InvId()].slot[tempInt].name);
								}
								Console.Read();
								break;
							}
						case "3":
							{
								Console.Write("slot> ");
								string tempInput = Console.ReadLine();
								tempBool = Int32.TryParse(tempInput, out tempInt);
								if (tempBool == true)
								{
									tempInt -= 1;
									ContainerItemDestroy(userInvInd, tempInt);
								}
								break;
							}
						case "4":
							{
								done = true;
								Console.Clear();
								displayMap(currentMap);
								break;
							}
						default:
							{
								Console.WriteLine("Unknown Command");
								break;
							}
					}
				}
				//run
				while (!done)
				{
					Console.Clear();
					Draw();
					usrInput();
				}

			}

			void ContainerUI(int Cont)
			{
				bool done = false;
				int userInvInd = objArray.FindIndex(item => item.name == "Inventory");
				void Draw()
				{
					Console.WriteLine(objArray[Cont].name);
					ContainerDisplay(Cont);
					Console.WriteLine("");

					Console.WriteLine(objArray[userInvInd].name);
					ContainerDisplay(userInvInd);
					Console.WriteLine("");
				}

				void usrInput()
				{
					Console.WriteLine("[0]Take");
					Console.WriteLine("[1]Put In");
					Console.WriteLine("[2]Destroy");
					Console.WriteLine("[3]Leave");
					Console.WriteLine("[4]Switch (?)");
					Console.Write("> ");
					string input = Console.ReadLine();
					switch (input)
					{
						case "0":
							{
								Console.Write("slot> ");
								string tempInput = Console.ReadLine();
								tempBool = Int32.TryParse(tempInput, out tempInt);
								if (tempBool == true)
								{
									tempInt -= 1;
									ContainerItemTransfer(false, Cont, tempInt);
								}
								break;
							}
						case "1":
							{
								Console.Write("slot> ");
								string tempInput = Console.ReadLine();
								tempBool = Int32.TryParse(tempInput, out tempInt);
								if (tempBool == true)
								{
									tempInt -= 1;
									ContainerItemTransfer(true, Cont, tempInt);
								}
								break;
							}
						case "2":
							{
								Console.Write("slot> ");
								string tempInput = Console.ReadLine();
								tempBool = Int32.TryParse(tempInput, out tempInt);
								tempInt -= 1;
								if (tempBool == true)
								{
									ContainerItemDestroy(Cont, tempInt);
								}
								break;
							}
						case "3":
							{
								done = true;
								Console.Clear();
								displayMap(currentMap);
								break;
							}
						default:
							{
								Console.WriteLine("Unknown Command");
								break;
							}
					}
				}

				//run
				while (!done)
				{
					Console.Clear();
					Draw();
					usrInput();
				}

			}

			void TestRoom()
			{
				Console.Clear();
				//InventoryContainer testInv = new InventoryContainer("testInv",5,0,0,0);
				//testInv.slot[0].name = "Paper";

				int tempInt9 = objArray.FindIndex(item => item.name == "testInv");
				int tempInt7 = objArray.FindIndex(item => item.name == "Inventory");
				ContainerItemAdd(tempInt9, "vape");
				ContainerItemAdd(tempInt9, "Paper", 4);
				ContainerItemAdd(tempInt9, "Feather", 3);
				ContainerItemAdd(tempInt9, "spoon");
				ContainerItemAdd(tempInt9, "dildo");

				ContainerItemAdd(tempInt7, "god");
				ContainerItemAdd(tempInt7, "Strange Key");
				ContainerItemAdd(tempInt7, "Medal",3);
				ContainerItemAdd(tempInt7, "dildo");
				ContainerItemAdd(tempInt7, "Bens Key");
				ContainerItemAdd(tempInt7, "Sams Key");
				//ContainerItemDestroy(tempInt9, 0);
				ContainerSort(tempInt9);
				ContainerDisplay(tempInt9);
				ContainerItemInspect(tempInt9, 0);
				Console.WriteLine(objArray[tempInt9].slot[0].description);

			}

			void userInput()
			{
				if (Console.CursorTop < 8)
				{
					Console.SetCursorPosition(0, 8);
				}
				Console.Write("> ");
				string input = Console.ReadLine();
				input.ToLower(); //formats input
				//Console.WriteLine(input.Length);

				switch (input)
				{
					case "show letter":
					case "display letter":
						{
							Player.OpenLetter();
							break;
						}
					case "   ":
						{
							TestRoom();
							break;
						}
					/*case "rh":
						{
							Player.health = Player.mhealth;
							break;
						}*/
					case "stats":
						{
							statsUI();
							displayMap(currentMap);
							break;
						}
					case "help":
						{
							Console.Clear();
							Console.WriteLine("Command list:\n\n" +
								"move right or mr\n" +
								"move up    or mu\n" +
								"move left  or ml\n" +
								"move down  or md\n" +
								"mr + number to move multiple spaces.\n" +
								"E.G. md 5  or mu 3\n\n" +
								"stats\n" +
								"inventory  or inv\n" +
								"");
							Console.WriteLine("Hit ENTER to continue");
							Console.Read();

							break;
						}
					case "interact left":
					case "il":
						{
							envInteract(-1, 0);
							break;
						}
					case "interact right":
					case "ir":
						{
							envInteract(1, 0);
							break;
						}
					case "interact up":
					case "iu":
						{
							envInteract(0, -1);
							break;
						}
					case "interact down":
					case "id":
						{
							envInteract(0, 1);
							break;
						}
					case "move up":
					case "mu":
						{
							Player.moveUp();
							displayMap(currentMap);
							break;
						}
					case "move down":
					case "md":
						{
							Player.moveDown();
							displayMap(currentMap);
							break;
						}
					case "move left":
					case "ml":
						{
							Player.moveLeft();
							displayMap(currentMap);
							break;
						}
					case "move right":
					case "mr":
						{
							Player.moveRight();
							displayMap(currentMap);
							break;
						}
					case "show map":
					case "display map":
					case "map":

						{
							displayMap(currentMap);
							break;
						}
					case "show inventory":
					case "display inventory":
					case "inventory":
					case "inv":
						{
							InventoryUI();
							break;
						}
					case "": //change
						{
							displayMap(currentMap);
							break;
						}
					default:
						{

							if ((input.Length > 4) && (input.Substring(0, 3) == "map"))
							{ //show different maps
								if (Convert.ToInt32(input.Substring(4)) < manyMaps)
								{
									displayMap(Convert.ToInt32(input.Substring(4)));
								}
								else
								{
									Console.WriteLine("That map doesnt exist");
								}
							}
							else if (input.Length > 3)
							{
								if ((input.Substring(0, 2) == "ml") //check if substrings equal any of the commands
								|| (input.Substring(0, 2) == "mr") //then remove user error by testing if theres a number
								|| (input.Substring(0, 2) == "mu") //by trying to convert last char/s to int
								|| (input.Substring(0, 2) == "md") //then runs the command if theyre equal to any command
								)
								{
									tempBool = Int32.TryParse(input.Substring(3), out tempInt);
									if (tempBool == true)
									{
										for (int x = 0; x < Convert.ToInt32(input.Substring(3)); x++)
										{
											if (input.Substring(0, 2) == "ml")
											{
												Player.moveLeft();
											}
											else if ((input.Substring(0, 2) == "mr"))
											{
												Player.moveRight();
											}
											else if ((input.Substring(0, 2) == "mu"))
											{
												Player.moveUp();
											}
											else if ((input.Substring(0, 2) == "md"))
											{
												Player.moveDown();
											}
											else
											{
												Console.WriteLine("Error input.substring if statement");
											}
										}
										displayMap(currentMap);
									}
								}
							}
							else if (input == "help")
							{
								//help method
							}
							else
							{
								Console.WriteLine("Unknown command");
							}

							break;
						}
				}

			}
			//--------------------------------------------------------------------//
			loadInMaps();
			Console.Clear();
			Console.WriteLine("Welcome");
			Console.WriteLine("Tips:");
			Console.WriteLine("");
			Console.WriteLine("- Use 'stats' to make yourself more powerful");
			Console.WriteLine("- You get more points from leveling up");
			Console.WriteLine("- Might want to talk to Franzi");
			Console.WriteLine("- Search the house for weapons and items");
			Console.WriteLine("- type 'help' for commands");
			while (true)
			{
				userInput();
			}

			while (stageDone[0] == false)
			{
				//code for stage 0 of the game
			};


			/*C  onsole.WriteLine ("Merle Is Awesome!");
			Console.SetCursorPosition (4, 0);
			System.Threading.Thread.Sleep(2000);
			Console.Write ("Y");
			*/
		}
	}
}