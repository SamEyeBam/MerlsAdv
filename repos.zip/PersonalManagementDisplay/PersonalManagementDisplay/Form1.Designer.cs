﻿using System;

namespace PersonalManagementDisplay
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tbDisplay = new System.Windows.Forms.TextBox();
			this.btnRefresh = new System.Windows.Forms.Button();
			this.btnDis = new System.Windows.Forms.Button();
			this.lbWeatherHeaderNotes = new System.Windows.Forms.Label();
			this.lbWeatherNotes = new System.Windows.Forms.Label();
			this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			this.button1 = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.checkBox2 = new System.Windows.Forms.CheckBox();
			this.btnSettings = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.lbTask = new System.Windows.Forms.Label();
			this.lbCountdown = new System.Windows.Forms.Label();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.lbBedTimeC = new System.Windows.Forms.Label();
			this.lbBedIn = new System.Windows.Forms.Label();
			this.lbBedTime = new System.Windows.Forms.Label();
			this.nudBedH = new System.Windows.Forms.NumericUpDown();
			this.nudBedM = new System.Windows.Forms.NumericUpDown();
			this.nudSleepH = new System.Windows.Forms.NumericUpDown();
			this.nudSleepM = new System.Windows.Forms.NumericUpDown();
			this.btnSleepUpdate = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.lbWakeUp = new System.Windows.Forms.Label();
			this.tableLayoutPanel2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.nudBedH)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.nudBedM)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.nudSleepH)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.nudSleepM)).BeginInit();
			this.SuspendLayout();
			// 
			// tbDisplay
			// 
			this.tbDisplay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.tbDisplay.Location = new System.Drawing.Point(509, 449);
			this.tbDisplay.Multiline = true;
			this.tbDisplay.Name = "tbDisplay";
			this.tbDisplay.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.tbDisplay.Size = new System.Drawing.Size(424, 60);
			this.tbDisplay.TabIndex = 0;
			// 
			// btnRefresh
			// 
			this.btnRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnRefresh.Location = new System.Drawing.Point(12, 486);
			this.btnRefresh.Name = "btnRefresh";
			this.btnRefresh.Size = new System.Drawing.Size(75, 23);
			this.btnRefresh.TabIndex = 1;
			this.btnRefresh.TabStop = false;
			this.btnRefresh.Text = "Refresh";
			this.btnRefresh.UseVisualStyleBackColor = true;
			this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
			// 
			// btnDis
			// 
			this.btnDis.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnDis.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.btnDis.FlatAppearance.BorderSize = 0;
			this.btnDis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnDis.Location = new System.Drawing.Point(93, 486);
			this.btnDis.Name = "btnDis";
			this.btnDis.Size = new System.Drawing.Size(75, 23);
			this.btnDis.TabIndex = 2;
			this.btnDis.Text = "dis";
			this.btnDis.UseVisualStyleBackColor = false;
			this.btnDis.Click += new System.EventHandler(this.btnDis_Click);
			// 
			// lbWeatherHeaderNotes
			// 
			this.lbWeatherHeaderNotes.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.lbWeatherHeaderNotes.AutoSize = true;
			this.lbWeatherHeaderNotes.Location = new System.Drawing.Point(3, 2);
			this.lbWeatherHeaderNotes.Name = "lbWeatherHeaderNotes";
			this.lbWeatherHeaderNotes.Size = new System.Drawing.Size(39, 15);
			this.lbWeatherHeaderNotes.TabIndex = 4;
			this.lbWeatherHeaderNotes.Text = "Notes";
			this.lbWeatherHeaderNotes.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lbWeatherNotes
			// 
			this.lbWeatherNotes.AutoSize = true;
			this.lbWeatherNotes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lbWeatherNotes.Location = new System.Drawing.Point(3, 20);
			this.lbWeatherNotes.Name = "lbWeatherNotes";
			this.lbWeatherNotes.Size = new System.Drawing.Size(11, 15);
			this.lbWeatherNotes.TabIndex = 5;
			this.lbWeatherNotes.Text = "-";
			this.lbWeatherNotes.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// tableLayoutPanel2
			// 
			this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.tableLayoutPanel2.ColumnCount = 1;
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel2.Controls.Add(this.lbWeatherNotes, 0, 1);
			this.tableLayoutPanel2.Controls.Add(this.lbWeatherHeaderNotes, 0, 0);
			this.tableLayoutPanel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tableLayoutPanel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
			this.tableLayoutPanel2.Location = new System.Drawing.Point(683, 12);
			this.tableLayoutPanel2.Name = "tableLayoutPanel2";
			this.tableLayoutPanel2.RowCount = 2;
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
			this.tableLayoutPanel2.Size = new System.Drawing.Size(250, 100);
			this.tableLayoutPanel2.TabIndex = 6;
			// 
			// button1
			// 
			this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.button1.Location = new System.Drawing.Point(428, 486);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 7;
			this.button1.Text = "delete";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox1.Controls.Add(this.lbWakeUp);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.btnSleepUpdate);
			this.groupBox1.Controls.Add(this.nudSleepM);
			this.groupBox1.Controls.Add(this.nudSleepH);
			this.groupBox1.Controls.Add(this.nudBedM);
			this.groupBox1.Controls.Add(this.nudBedH);
			this.groupBox1.Controls.Add(this.checkBox2);
			this.groupBox1.ForeColor = System.Drawing.SystemColors.Control;
			this.groupBox1.Location = new System.Drawing.Point(509, 380);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(424, 63);
			this.groupBox1.TabIndex = 8;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Settings";
			// 
			// checkBox2
			// 
			this.checkBox2.AutoSize = true;
			this.checkBox2.Location = new System.Drawing.Point(6, 40);
			this.checkBox2.Name = "checkBox2";
			this.checkBox2.Size = new System.Drawing.Size(80, 17);
			this.checkBox2.TabIndex = 1;
			this.checkBox2.Text = "checkBox2";
			this.checkBox2.UseVisualStyleBackColor = true;
			// 
			// btnSettings
			// 
			this.btnSettings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnSettings.Location = new System.Drawing.Point(174, 486);
			this.btnSettings.Name = "btnSettings";
			this.btnSettings.Size = new System.Drawing.Size(24, 23);
			this.btnSettings.TabIndex = 9;
			this.btnSettings.Text = "@";
			this.btnSettings.UseVisualStyleBackColor = true;
			this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox2.Controls.Add(this.lbCountdown);
			this.groupBox2.Controls.Add(this.lbTask);
			this.groupBox2.Location = new System.Drawing.Point(618, 263);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(315, 111);
			this.groupBox2.TabIndex = 10;
			this.groupBox2.TabStop = false;
			// 
			// lbTask
			// 
			this.lbTask.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lbTask.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbTask.ForeColor = System.Drawing.Color.Coral;
			this.lbTask.Location = new System.Drawing.Point(6, 16);
			this.lbTask.Name = "lbTask";
			this.lbTask.Size = new System.Drawing.Size(113, 85);
			this.lbTask.TabIndex = 0;
			this.lbTask.Text = "Wake Up";
			// 
			// lbCountdown
			// 
			this.lbCountdown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lbCountdown.AutoSize = true;
			this.lbCountdown.Font = new System.Drawing.Font("Microsoft Sans Serif", 56F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbCountdown.ForeColor = System.Drawing.Color.Coral;
			this.lbCountdown.Location = new System.Drawing.Point(125, 16);
			this.lbCountdown.Name = "lbCountdown";
			this.lbCountdown.Size = new System.Drawing.Size(184, 85);
			this.lbCountdown.TabIndex = 1;
			this.lbCountdown.Text = "5:00";
			// 
			// groupBox3
			// 
			this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox3.Controls.Add(this.lbBedTime);
			this.groupBox3.Controls.Add(this.lbBedTimeC);
			this.groupBox3.Controls.Add(this.lbBedIn);
			this.groupBox3.Location = new System.Drawing.Point(618, 118);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(315, 139);
			this.groupBox3.TabIndex = 11;
			this.groupBox3.TabStop = false;
			// 
			// lbBedTimeC
			// 
			this.lbBedTimeC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lbBedTimeC.AutoSize = true;
			this.lbBedTimeC.Font = new System.Drawing.Font("Microsoft Sans Serif", 56F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbBedTimeC.ForeColor = System.Drawing.Color.Coral;
			this.lbBedTimeC.Location = new System.Drawing.Point(6, 48);
			this.lbBedTimeC.Name = "lbBedTimeC";
			this.lbBedTimeC.Size = new System.Drawing.Size(289, 85);
			this.lbBedTimeC.TabIndex = 1;
			this.lbBedTimeC.Text = "0:00:00";
			// 
			// lbBedIn
			// 
			this.lbBedIn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lbBedIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbBedIn.ForeColor = System.Drawing.Color.Coral;
			this.lbBedIn.Location = new System.Drawing.Point(6, 16);
			this.lbBedIn.Name = "lbBedIn";
			this.lbBedIn.Size = new System.Drawing.Size(113, 35);
			this.lbBedIn.TabIndex = 0;
			this.lbBedIn.Text = "Bed In";
			// 
			// lbBedTime
			// 
			this.lbBedTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lbBedTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbBedTime.ForeColor = System.Drawing.Color.Coral;
			this.lbBedTime.Location = new System.Drawing.Point(235, 16);
			this.lbBedTime.Name = "lbBedTime";
			this.lbBedTime.Size = new System.Drawing.Size(74, 35);
			this.lbBedTime.TabIndex = 2;
			this.lbBedTime.Text = "00:00";
			// 
			// nudBedH
			// 
			this.nudBedH.Location = new System.Drawing.Point(249, 38);
			this.nudBedH.Name = "nudBedH";
			this.nudBedH.Size = new System.Drawing.Size(45, 20);
			this.nudBedH.TabIndex = 2;
			// 
			// nudBedM
			// 
			this.nudBedM.Location = new System.Drawing.Point(300, 38);
			this.nudBedM.Name = "nudBedM";
			this.nudBedM.Size = new System.Drawing.Size(45, 20);
			this.nudBedM.TabIndex = 3;
			// 
			// nudSleepH
			// 
			this.nudSleepH.Location = new System.Drawing.Point(249, 12);
			this.nudSleepH.Name = "nudSleepH";
			this.nudSleepH.Size = new System.Drawing.Size(45, 20);
			this.nudSleepH.TabIndex = 4;
			// 
			// nudSleepM
			// 
			this.nudSleepM.Location = new System.Drawing.Point(300, 12);
			this.nudSleepM.Name = "nudSleepM";
			this.nudSleepM.Size = new System.Drawing.Size(45, 20);
			this.nudSleepM.TabIndex = 5;
			// 
			// btnSleepUpdate
			// 
			this.btnSleepUpdate.FlatAppearance.BorderSize = 0;
			this.btnSleepUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnSleepUpdate.Location = new System.Drawing.Point(349, 35);
			this.btnSleepUpdate.Name = "btnSleepUpdate";
			this.btnSleepUpdate.Size = new System.Drawing.Size(69, 23);
			this.btnSleepUpdate.TabIndex = 12;
			this.btnSleepUpdate.Text = "Update";
			this.btnSleepUpdate.UseVisualStyleBackColor = true;
			this.btnSleepUpdate.Click += new System.EventHandler(this.btnSleepUpdate_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(208, 14);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(37, 13);
			this.label1.TabIndex = 13;
			this.label1.Text = "Sleep:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(214, 41);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(29, 13);
			this.label2.TabIndex = 14;
			this.label2.Text = "Bed:";
			// 
			// lbWakeUp
			// 
			this.lbWakeUp.AutoSize = true;
			this.lbWakeUp.ForeColor = System.Drawing.Color.Coral;
			this.lbWakeUp.Location = new System.Drawing.Point(360, 14);
			this.lbWakeUp.Name = "lbWakeUp";
			this.lbWakeUp.Size = new System.Drawing.Size(44, 13);
			this.lbWakeUp.TabIndex = 15;
			this.lbWakeUp.Text = "0:00AM";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
			this.ClientSize = new System.Drawing.Size(945, 521);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.btnSettings);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.tableLayoutPanel2);
			this.Controls.Add(this.btnDis);
			this.Controls.Add(this.btnRefresh);
			this.Controls.Add(this.tbDisplay);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.tableLayoutPanel2.ResumeLayout(false);
			this.tableLayoutPanel2.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.nudBedH)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.nudBedM)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.nudSleepH)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.nudSleepM)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}


		#endregion

		private System.Windows.Forms.TextBox tbDisplay;
		private System.Windows.Forms.Button btnRefresh;
		private System.Windows.Forms.Button btnDis;
		private System.Windows.Forms.Label lbWeatherHeaderNotes;
		private System.Windows.Forms.Label lbWeatherNotes;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.CheckBox checkBox2;
		private System.Windows.Forms.Button btnSettings;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label lbCountdown;
		private System.Windows.Forms.Label lbTask;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.Label lbBedTimeC;
		private System.Windows.Forms.Label lbBedIn;
		private System.Windows.Forms.Label lbBedTime;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnSleepUpdate;
		private System.Windows.Forms.NumericUpDown nudSleepM;
		private System.Windows.Forms.NumericUpDown nudSleepH;
		private System.Windows.Forms.NumericUpDown nudBedM;
		private System.Windows.Forms.NumericUpDown nudBedH;
		private System.Windows.Forms.Label lbWakeUp;
	}
}

