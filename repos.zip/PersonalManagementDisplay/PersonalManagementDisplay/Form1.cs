﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace PersonalManagementDisplay
{
	public partial class Form1 : Form
	{
		string jsonText;
		BasicForecast basicForecast;
		HourlyForecast hourlyForecast;

		Routine routine;
		int bedTimeH = 22;
		int bedTimeM = 00;
		int sleepNeededH = 8;
		int sleepNeededM = 20;
		int routineStartH;
		int routineStartM;

		static int weatherRowSize = 12;
		bool weatherDisHour = true;
		bool weatherDisTemp = true;
		bool weatherDisFeelsLike = true;
		bool weatherDisHumidity = true;
		bool weatherDisRainfall = true;
		bool weatherDisConditions = true;
		int tempInt;
		int weatherDisColumnCount; //set in Form1()
		public Label[,] LbWeather = new Label[weatherRowSize,6]; //might have to change weatherRow to a set number (if settings change, wont create bigger array)
		JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
		{
			NullValueHandling = NullValueHandling.Ignore,
			MissingMemberHandling = MissingMemberHandling.Ignore
		};

		TableLayoutPanel tlpWeather = new TableLayoutPanel();
		TableLayoutPanel tlpRoutine = new TableLayoutPanel();
		public Label[,] LbRoutine;
		Label routineHeader;
		Label[] LbRoutineHeader = new Label[2];

		System.Timers.Timer myTimer = new System.Timers.Timer(1000);
		int countdownIndex = 0;
		int countdownM = 5;
		int countdownS = 0;
		bool routineStart = false;

		public Form1()
		{
			InitializeComponent();
			weatherDisColumnCount = WeatherColumnCount();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			//basic
			jsonText = System.IO.File.ReadAllText(@"C:\Users\PC\Documents\test_folder\BasicForecastjsonTest.txt");
			basicForecast = JsonConvert.DeserializeObject<BasicForecast>(jsonText, jsonSerializerSettings);
			//hourly
			jsonText = System.IO.File.ReadAllText(@"C:\Users\PC\Documents\test_folder\HourlyForecastjsonTest.txt");
			hourlyForecast = JsonConvert.DeserializeObject<HourlyForecast>(jsonText, jsonSerializerSettings);
			//routine
			jsonText = System.IO.File.ReadAllText(@"C:\Users\PC\Documents\test_folder\RoutinejsonTest.txt");
			routine = JsonConvert.DeserializeObject<Routine>(jsonText, jsonSerializerSettings);

			CreateWeatherTable();
			displayTodaysForcast();
			initVarAssign();
			TLPRoutineCreate();

			myTimer.Elapsed += UpdateLabel;
			myTimer.Start();

		}

		
		private void UpdateLabel(object sender, ElapsedEventArgs e)
		{
			TimeSpan start = new TimeSpan(routineStartH, routineStartM, 0);
			TimeSpan end = new TimeSpan(12, 0, 0);
			TimeSpan now = DateTime.Now.TimeOfDay;
			

			TimeSpan bedTime = new TimeSpan(bedTimeH, bedTimeM, 0);
			TimeSpan testSpan = (bedTime - now);
			string tmpString = testSpan.Hours.ToString() + ":";
			if (testSpan.Minutes < 10)
			{
				tmpString += "0";
			}
			tmpString += testSpan.Minutes.ToString() + ":";
			if (testSpan.Seconds < 10)
			{
				tmpString += "0";
			}
			tmpString += testSpan.Seconds.ToString();
			lbBedTimeC.Invoke((Action)(() => lbBedTimeC.Text = tmpString));

			if ((routineStart == false)&& (now > start) && (now < end))
			{
				//MessageBox.Show(now.ToString());
				routineStart = true;
				RefreshWebData();
				this.Invoke((Action)(() => displayTodaysForcast()));
			}

			void countdownAssign(int x)
			{
				countdownS = 0;
				countdownM = routine.RoutineItem[x].timeToComplete;
				lbTask.Invoke((Action)(() => lbTask.Text = routine.RoutineItem[x].text));
			}
			if (routineStart == true) {
				countdownS -= 1;
				if (countdownS < 0)
				{
					countdownS = 59;
					countdownM -= 1;
				}
				if (countdownM < 0)
				{
					countdownIndex += 1;
					countdownAssign(countdownIndex);
				}
				string tempString = countdownM.ToString() + ":";
				if (countdownS < 10)
				{
					tempString += "0";
				}
				lbCountdown.Invoke((Action)(() => lbCountdown.Text = tempString + countdownS.ToString()));
			}
			
			//lbCountdown.Text = tempString + countdownS.ToString();
		}

		public void initVarAssign()
		{
			routineStartH = bedTimeH + sleepNeededH;
			if (routineStartH > 23) { routineStartH -= 24; }
			routineStartM = bedTimeM + sleepNeededM;
			if (routineStartM >59) { routineStartM -= 60; routineStartH += 1; }

			string tmpString = (bedTimeH - 12).ToString() + ":";
			if (bedTimeM < 10)
			{
				tmpString += "0";
			}
			lbBedTime.Text = tmpString + bedTimeM.ToString();

			nudBedH.Value = bedTimeH - 12;
			nudBedM.Value = bedTimeM;

			nudSleepH.Value = sleepNeededH;
			nudSleepM.Value = sleepNeededM;

			lbWakeUp.Text = routineStartH.ToString() + ":" + routineStartM.ToString();

		}

		public int WeatherColumnCount()
		{
			int temp1 = 0;
			if (weatherDisHour == true) { temp1 += 1; }
			if (weatherDisTemp == true) { temp1 += 1; }
			if (weatherDisFeelsLike == true) { temp1 += 1; }
			if (weatherDisHumidity == true) { temp1 += 1; }
			if (weatherDisRainfall == true) { temp1 += 1; }
			if (weatherDisConditions == true) { temp1 += 1; }


			return temp1;

		} //delete

		public string basicForecastDisplayText()
		{
			return	"Date: " + basicForecast.forecast.simpleforecast.forecastday[0].date.day + Environment.NewLine +
					"Period: " + basicForecast.forecast.simpleforecast.forecastday[0].period + Environment.NewLine +
					"High: " + basicForecast.forecast.simpleforecast.forecastday[0].high.celsius + Environment.NewLine +
					"Low: " + basicForecast.forecast.simpleforecast.forecastday[0].low.celsius + Environment.NewLine +
					"Conditions: " + basicForecast.forecast.simpleforecast.forecastday[0].conditions + Environment.NewLine +
					"Max Wind: " + basicForecast.forecast.simpleforecast.forecastday[0].maxwind.kph + Environment.NewLine +
					"Ave Wind: " + basicForecast.forecast.simpleforecast.forecastday[0].avewind.kph + Environment.NewLine;
		} //delete

		public string HourlyForecastDisplayText()
		{
			return	"Date: " + hourlyForecast.hourly_forecast[0].FCTTIME.mday + Environment.NewLine +
					"Hour: " + hourlyForecast.hourly_forecast[0].FCTTIME.hour + Environment.NewLine +
					"Temp: " + hourlyForecast.hourly_forecast[0].temp.metric + Environment.NewLine +
					"Feels like: " + hourlyForecast.hourly_forecast[0].feelslike.metric + Environment.NewLine +
					"Humidity: " + hourlyForecast.hourly_forecast[0].humidity + Environment.NewLine +
					"Conditions: " + hourlyForecast.hourly_forecast[0].condition + Environment.NewLine +
					"Wind Speed: " + hourlyForecast.hourly_forecast[0].wspd.metric + Environment.NewLine +
					"Rain: " + hourlyForecast.hourly_forecast[0].qpf.metric + Environment.NewLine;
		} //delete

		public void CreateWeatherTable()
		{
			string labelFont = "Segoe UI";
			int labelFontSize = 14;
			int labelSizeW = 0;
			int labelSizeH = 0;
			int labelPaddingL = 0;
			int labelPaddingR = 0;
			int labelPaddingU = 0;
			int labelPaddingD = 0;


			tlpWeather.Location = new System.Drawing.Point(300, 5);
			tlpWeather.Name = "tlpWeather1";
			tlpWeather.Size = new System.Drawing.Size(50, 50);
			tlpWeather.AutoSize = true;
			tlpWeather.BackColor = Color.FromArgb(255, 32, 32, 32);
			tlpWeather.ForeColor = Color.FromArgb(255, 255, 130, 0);
			tlpWeather.Margin = new Padding(5, 5, 5, 5);
			tlpWeather.Font = new Font(labelFont, labelFontSize);
			//
			tlpWeather.ColumnCount = weatherDisColumnCount;
			tlpWeather.RowCount = weatherRowSize;

			//create colomns
			for (int i = 0; i < tlpWeather.ColumnCount; i++)
			{
				tlpWeather.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
			}
			//create rows
			for (int j = 0; j < tlpWeather.RowCount; j++)
			{
				tlpWeather.RowStyles.Add(new RowStyle(SizeType.AutoSize));
			}
			//create labels
			for (int i = 0; i < tlpWeather.ColumnCount; i++)
			{
				for (int j = 0; j < tlpWeather.RowCount; j++)
				{
					LbWeather[j, i] = new Label
					{
						Location = new Point(0, 0),
						Text = "-",
						Size = new Size(labelSizeW, labelSizeH),
						AutoSize = true,
						Margin = new Padding(labelPaddingL, labelPaddingU, labelPaddingR, labelPaddingD),
						//ImageAlign = ContentAlignment.MiddleCenter,
						TextAlign = ContentAlignment.MiddleCenter,
						Anchor = (AnchorStyles.Left | AnchorStyles.Right)
					};
					tlpWeather.Controls.Add(LbWeather[j, i], i, j + 1);
				}
			}

			tempInt = 0;
			//header label create and position
			if (weatherDisHour == true)
			{
				Label lbWeatherHeaderHour = new Label
				{
					Location = new Point(0, 0),
					Text = "Hour",
					Size = new Size(labelSizeW, labelSizeH),
					AutoSize = true,
					Margin = new Padding(labelPaddingL, labelPaddingU, labelPaddingR, labelPaddingD),
					Anchor = (AnchorStyles.Left | AnchorStyles.Right),
					TextAlign = ContentAlignment.MiddleCenter//
				};
				tlpWeather.Controls.Add(lbWeatherHeaderHour, tempInt, 0);
				tempInt += 1;
			} //replicate alignment for other headers TODO
			if (weatherDisTemp == true)
			{
				Label lbWeatherHeaderTemp = new Label
				{
					Location = new Point(0, 0),
					Text = "Temp",
					Size = new Size(labelSizeW, labelSizeH),
					AutoSize = true,
					Margin = new Padding(labelPaddingL, labelPaddingU, labelPaddingR, labelPaddingD)
					//Anchor = AnchorStyles.Left
				};
				tlpWeather.Controls.Add(lbWeatherHeaderTemp, tempInt, 0);
				tempInt += 1;
			}
			if (weatherDisFeelsLike == true)
			{
				Label lbWeatherHeaderFeelsLike = new Label
				{
					Location = new Point(0, 0),
					Text = "FL",
					Size = new Size(labelSizeW, labelSizeH),
					AutoSize = true,
					Margin = new Padding(labelPaddingL, labelPaddingU, labelPaddingR, labelPaddingD)
					//Anchor = AnchorStyles.Left
				};
				tlpWeather.Controls.Add(lbWeatherHeaderFeelsLike, tempInt, 0);
				tempInt += 1;
			}
			if (weatherDisHumidity == true)
			{
				Label lbWeatherHeaderHumidity = new Label
				{
					Location = new Point(0, 0),
					Text = "Hum",
					Size = new Size(labelSizeW, labelSizeH),
					AutoSize = true,
					Margin = new Padding(labelPaddingL, labelPaddingU, labelPaddingR, labelPaddingD)
					//Anchor = AnchorStyles.Left
				};
				tlpWeather.Controls.Add(lbWeatherHeaderHumidity, tempInt, 0);
				tempInt += 1;
			}
			if (weatherDisRainfall == true)
			{
				Label lbWeatherHeaderRainfall = new Label
				{
					Location = new Point(0, 0),
					Text = "Rain",
					Size = new Size(labelSizeW, labelSizeH),
					AutoSize = true,
					Margin = new Padding(labelPaddingL, labelPaddingU, labelPaddingR, labelPaddingD)
					//Anchor = AnchorStyles.Left
				};
				tlpWeather.Controls.Add(lbWeatherHeaderRainfall, tempInt, 0);
				tempInt += 1;
			}
			if (weatherDisConditions == true)
			{
				Label lbWeatherHeaderConditions = new Label
				{
					Location = new Point(0, 0),
					Text = "Conditions",
					Font = new Font(labelFont, 16, FontStyle.Bold),
					Size = new Size(labelSizeW, labelSizeH),
					AutoSize = true,
					Margin = new Padding(labelPaddingL, labelPaddingU, labelPaddingR, labelPaddingD),
					Anchor = (AnchorStyles.Left | AnchorStyles.Right),
					TextAlign = ContentAlignment.MiddleCenter//
				};
				tlpWeather.Controls.Add(lbWeatherHeaderConditions, tempInt, 0);
				tempInt += 1;
			}

			// Add child controls to TableLayoutPanel and specify rows and column

			Controls.Add(tlpWeather);
		} //delete

		public void displayTodaysForcast()
		{
			#region
			bool bringBeanie = false;
			bool bringHat = false;
			bool bringJacket = false;
			bool bringGloves = false;
			bool bringBoots = false;

			int time;
			int temp;
			int feelsLike;
			int humidity;
			int rainfall;
			string conditions;

			if (basicForecast.forecast.simpleforecast.forecastday[0].qpf_allday.mm > 10)
			{
				bringBoots = true;
			}
			
			for (int x = 0; x < weatherRowSize; x++)
			{
				tempInt = 0;
				time = Int32.Parse(hourlyForecast.hourly_forecast[x].FCTTIME.hour);
				temp = Int32.Parse(hourlyForecast.hourly_forecast[x].temp.metric);
				feelsLike = Int32.Parse(hourlyForecast.hourly_forecast[x].feelslike.metric);
				humidity = Int32.Parse(hourlyForecast.hourly_forecast[x].humidity);
				rainfall = Int32.Parse(hourlyForecast.hourly_forecast[x].qpf.metric);
				conditions = hourlyForecast.hourly_forecast[x].condition;


				//Notes - check bring
				if ((time >= 14) & (time <= 20))
				{
					if (feelsLike < 17)
					{
						bringJacket = true;
					}

					if (temp > 25)
					{
						bringHat = true;
					}

					if (feelsLike < 13)
					{
						bringBeanie = true;
					}

					if (feelsLike < 8)
					{
						bringGloves = true;
					}
				}
				//string construction
				if (bringBeanie == true || bringJacket == true || bringGloves == true || bringBoots == true || bringHat == true)
				{
					string tempStr = "Bring:" + Environment.NewLine + Environment.NewLine;
					if (bringBeanie == true)
					{
						tempStr += "Beanie" + Environment.NewLine;
					}
					if (bringHat == true)
					{
						tempStr += "Hat" + Environment.NewLine;
					}
					if (bringJacket == true)
					{
						tempStr += "Jacket" + Environment.NewLine;
					}
					if (bringGloves == true)
					{
						tempStr += "Gloves" + Environment.NewLine;
					}
					if (bringBoots == true)
					{
						tempStr += "Boots";
					}
					lbWeatherNotes.Text = tempStr;
				}
				else
				{
					lbWeatherNotes.Text = "Looks like the weather is prime";
				}
				#endregion
				//------------------------------------------------------
				//time
				if (weatherDisHour == true)
				{
					if (time > 12)
					{
						LbWeather[x, tempInt].Text = (time - 12).ToString() + " PM";
						tempInt += 1;
					}
					else
					{
						LbWeather[x, tempInt].Text = time.ToString() + " AM";
						tempInt += 1;
					}
				}
				//temp
				if (weatherDisTemp == true)
				{
					LbWeather[x, tempInt].Text = temp.ToString() + "C";
					tempInt += 1;
				}
				//feels like
				if (weatherDisFeelsLike == true)
				{
					LbWeather[x, tempInt].Text = feelsLike.ToString() + "C";
					tempInt += 1;
				}
				//humidity
				if (weatherDisHumidity == true)
				{
					LbWeather[x, tempInt].Text = humidity.ToString() + "%";
					tempInt += 1;
				}
				//rainfall
				if (weatherDisRainfall == true)
				{
					LbWeather[x, tempInt].Text = rainfall.ToString() + "ml";
					tempInt += 1;
				}
				//conditions
				if (weatherDisConditions == true)
				{
					LbWeather[x, tempInt].Text = conditions;
					tempInt += 1;
				}
			}
		} //delete

		public void RefreshWebData()
		{
			string urlData = String.Empty;
			WebClient wc = new WebClient();
			//basic
			jsonText = wc.DownloadString("http://api.wunderground.com/api/830c974d105f7c03/forecast/q/new_zealand/christchurch.json");
			basicForecast = JsonConvert.DeserializeObject<BasicForecast>(jsonText, jsonSerializerSettings);
			//hourly
			jsonText = wc.DownloadString("http://api.wunderground.com/api/830c974d105f7c03/hourly/q/new_zealand/christchurch.json");
			hourlyForecast = JsonConvert.DeserializeObject<HourlyForecast>(jsonText, jsonSerializerSettings);
		}

		public void RefreshRoutineData()
		{
			jsonText = System.IO.File.ReadAllText(@"C:\Users\PC\Documents\test_folder\RoutinejsonTest.txt");
			routine = JsonConvert.DeserializeObject<Routine>(jsonText, jsonSerializerSettings);
		}

		public int routineTaskCount()
		{
			int taskCount = 0;
			foreach (var item in routine.RoutineItem)
			{
				if (item.enabled)
				{
					if (item.Time.boolReoccur)
					{
						if (item.Time.reoccur == "Daily")
						{
							taskCount += 1;
						}
						else if (item.Time.reoccur == "Weekly")
						{
							for (int i = 0; i < 7; i++)
							{
								if ((item.Time.Days[i] == true) & (i == ((int)(System.DateTime.Now.DayOfWeek + 6) % 7)))
								{
									taskCount += 1;
								}
							}
						}
						else if (item.Time.reoccur == "Doesnt")
						{
							//
						}
					}
				}
			}
			return taskCount;
		}

		public void TLPRoutineCreate()
		{
			int taskCount = routineTaskCount();
			//LbRoutine = new Label[taskCount, 2];
			LbRoutine = new Label[taskCount, 2];

			string labelFont = "Segoe UI";
			int labelFontSize = 16;
			int labelSizeW = 0;
			int labelSizeH = 0;
			int labelPaddingL = 0;
			int labelPaddingR = 0;
			int labelPaddingU = 0;
			int labelPaddingD = 0;

			routineHeader = new Label
			{
				Location = new Point(85, 5),
				Text = "Routine",
				AutoSize = true,
				ForeColor = Color.FromArgb(255, 255, 130, 0),
				Font = new Font(labelFont, labelFontSize)
			};
			this.Controls.Add(routineHeader);

			tlpRoutine.Location = new System.Drawing.Point(5, 35);
			tlpRoutine.Name = "tlpRoutine1";
			tlpRoutine.Size = new System.Drawing.Size(50, 50);
			tlpRoutine.AutoSize = true;
			tlpRoutine.BackColor = Color.FromArgb(255, 32, 32, 32);
			tlpRoutine.ForeColor = Color.FromArgb(255, 255, 130, 0);
			tlpRoutine.Margin = new Padding(5, 5, 5, 5);
			tlpRoutine.Font = new Font(labelFont, labelFontSize);

			tlpRoutine.ColumnCount = 2;
			tlpRoutine.RowCount = taskCount;

			//create colomns
			tlpRoutine.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,75F));
			tlpRoutine.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,25F));
			//create rows
			for (int j = 0; j < tlpRoutine.RowCount; j++)
			{
				tlpRoutine.RowStyles.Add(new RowStyle(SizeType.Absolute,25F));
			}

			//create labels
			for (int i = 0; i < tlpRoutine.ColumnCount; i++)
			{
				for (int j = 0; j < tlpRoutine.RowCount; j++)
				{
					LbRoutine[j,i] = new Label
					{
						//Location = new Point(0, 0),
						Text = "-",
						//Size = new Size(labelSizeW, labelSizeH),
						AutoSize = true,
						//Margin = new Padding(labelPaddingL, labelPaddingU, labelPaddingR, labelPaddingD),
						//ImageAlign = ContentAlignment.MiddleCenter,
						//TextAlign = ContentAlignment.MiddleLeft,
						Anchor = (AnchorStyles.Left)
					};
					tlpRoutine.Controls.Add(LbRoutine[j,i], i, j + 1);
					//MessageBox.Show("label created");
				}
			}

			//header
			for (int i = 0; i < LbRoutineHeader.Length; i++)
			{
				LbRoutineHeader[i] = new Label
				{
					Location = new Point(0, 0),
					Text = "-",
					Size = new Size(labelSizeW, labelSizeH),
					AutoSize = true,
					Margin = new Padding(labelPaddingL, labelPaddingU, labelPaddingR, labelPaddingD),
					//ImageAlign = ContentAlignment.MiddleCenter,
					TextAlign = ContentAlignment.MiddleCenter,
					Anchor = (AnchorStyles.Left)
				};
				tlpRoutine.Controls.Add(LbRoutineHeader[i], i, 0);
			}
			LbRoutineHeader[0].Text = "Task";
			LbRoutineHeader[1].Text = "Time";

			Controls.Add(tlpRoutine);
			TLPRoutineRefresh();
		}

		public void TLPRoutineRefresh()
		{
			int row = 0;
			int Hour = routineStartH;
			int Minute = routineStartM;

			string timeSet(int x)
			{
				string tempString;
				Minute += x;
				if (Minute > 59) { Minute -= 60; Hour += 1; }
				tempString = Hour.ToString() + ":";
				if (Minute < 10) { tempString += "0"; }
				tempString += Minute.ToString();

				return tempString ;//
			}

			foreach (var item in routine.RoutineItem)
			{
				if (item.enabled)
				{
					if (item.Time.boolReoccur)
					{
						if (item.Time.reoccur == "Daily")
						{
							LbRoutine[row, 0].Text = item.text;
							LbRoutine[row, 1].Text = timeSet(item.timeToComplete);
							row += 1;
						}
						else if (item.Time.reoccur == "Weekly")
						{
							for (int i = 0; i < 7; i++)
							{
								if ((item.Time.Days[i] == true) & (i == ((int)(System.DateTime.Now.DayOfWeek + 6) % 7)))
								{
									LbRoutine[row, 0].Text = item.text;
									LbRoutine[row, 1].Text = timeSet(item.timeToComplete);
									row += 1;
								}
							}
						}
						else if (item.Time.reoccur == "Doesnt")
						{
							//
						}
					}
				}
			}
		}

		private void btnRefresh_Click(object sender, EventArgs e)
		{
			RefreshWebData();
		} //delete add to display

		private void btnDis_Click(object sender, EventArgs e)
		{
			RefreshWebData();
			
			Console.WriteLine(basicForecast.forecast.txt_forecast.forecastday[0].fcttext_metric);

			tbDisplay.Text = basicForecastDisplayText();
			tbDisplay.Text += Environment.NewLine;
			tbDisplay.Text += HourlyForecastDisplayText();
			//tbDisplay.Text = basicForecast.forecast.txt_forecast.forecastday[0].fcttext_metric;

			displayTodaysForcast();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			MessageBox.Show(routine.RoutineItem.Length.ToString() + " " + tlpRoutine.RowCount.ToString() + " " + LbRoutine.Length.ToString());
		} //delete

		private void btnSettings_Click(object sender, EventArgs e)
		{
			tempInt = routineTaskCount();
			// Create a new instance of the Form2 class
			Form2 settingsForm = new Form2();
			// Show the settings form
			settingsForm.ShowDialog();
			RefreshRoutineData();

			if (tempInt != routineTaskCount())
			{
				Application.Restart();
			}

			TLPRoutineRefresh();
		}

		private void btnSleepUpdate_Click(object sender, EventArgs e)
		{
			sleepNeededH = Convert.ToInt32(nudSleepH.Value);
			sleepNeededM = Convert.ToInt32(nudSleepM.Value);

			bedTimeH = Convert.ToInt32(nudBedH.Value) + 12;
			bedTimeM = Convert.ToInt32(nudBedM.Value);

			string tmpString = (bedTimeH - 12).ToString() + ":";
			if (bedTimeM < 10)
			{
				tmpString += "0";
			}
			lbBedTime.Text = tmpString + bedTimeM.ToString();

			routineStartH = bedTimeH + sleepNeededH;
			if (routineStartH > 23) { routineStartH -= 24; }
			routineStartM = bedTimeM + sleepNeededM;
			if (routineStartM > 59) { routineStartM -= 60; routineStartH += 1; }

			lbWakeUp.Text = routineStartH.ToString() + ":" + routineStartM.ToString();
			TLPRoutineRefresh();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			routineStart = false;
		}


		//BasicForecast basicForecast = = JsonConvert.DeserializeObject<BasicForecast>(json);

	}
}
