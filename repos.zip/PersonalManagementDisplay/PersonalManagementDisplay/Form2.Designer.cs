﻿namespace PersonalManagementDisplay
{
	partial class Form2
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnDone = new System.Windows.Forms.Button();
			this.TlpWeekly = new System.Windows.Forms.TableLayoutPanel();
			this.CkbSunday = new System.Windows.Forms.CheckBox();
			this.CkbSaturday = new System.Windows.Forms.CheckBox();
			this.CkbFriday = new System.Windows.Forms.CheckBox();
			this.CkbThursday = new System.Windows.Forms.CheckBox();
			this.CkbWednesday = new System.Windows.Forms.CheckBox();
			this.CkbTuesday = new System.Windows.Forms.CheckBox();
			this.CkbMonday = new System.Windows.Forms.CheckBox();
			this.label13 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.CbReoccur = new System.Windows.Forms.ComboBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.CbPriority = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.NudTimeToComplete = new System.Windows.Forms.NumericUpDown();
			this.label2 = new System.Windows.Forms.Label();
			this.TbName = new System.Windows.Forms.TextBox();
			this.LbName = new System.Windows.Forms.Label();
			this.CbSub = new System.Windows.Forms.ComboBox();
			this.label14 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.button2 = new System.Windows.Forms.Button();
			this.btnSave = new System.Windows.Forms.Button();
			this.btnAdd = new System.Windows.Forms.Button();
			this.TlpWeekly.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.NudTimeToComplete)).BeginInit();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnDone
			// 
			this.btnDone.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnDone.Location = new System.Drawing.Point(596, 390);
			this.btnDone.Name = "btnDone";
			this.btnDone.Size = new System.Drawing.Size(75, 23);
			this.btnDone.TabIndex = 0;
			this.btnDone.Text = "Done";
			this.btnDone.UseVisualStyleBackColor = true;
			this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
			// 
			// TlpWeekly
			// 
			this.TlpWeekly.ColumnCount = 7;
			this.TlpWeekly.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.TlpWeekly.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.TlpWeekly.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.TlpWeekly.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.TlpWeekly.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.TlpWeekly.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.TlpWeekly.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.TlpWeekly.Controls.Add(this.CkbSunday, 6, 1);
			this.TlpWeekly.Controls.Add(this.CkbSaturday, 5, 1);
			this.TlpWeekly.Controls.Add(this.CkbFriday, 4, 1);
			this.TlpWeekly.Controls.Add(this.CkbThursday, 3, 1);
			this.TlpWeekly.Controls.Add(this.CkbWednesday, 2, 1);
			this.TlpWeekly.Controls.Add(this.CkbTuesday, 1, 1);
			this.TlpWeekly.Controls.Add(this.CkbMonday, 0, 1);
			this.TlpWeekly.Controls.Add(this.label13, 6, 0);
			this.TlpWeekly.Controls.Add(this.label12, 5, 0);
			this.TlpWeekly.Controls.Add(this.label11, 4, 0);
			this.TlpWeekly.Controls.Add(this.label10, 3, 0);
			this.TlpWeekly.Controls.Add(this.label9, 2, 0);
			this.TlpWeekly.Controls.Add(this.label8, 1, 0);
			this.TlpWeekly.Controls.Add(this.label7, 0, 0);
			this.TlpWeekly.Location = new System.Drawing.Point(26, 132);
			this.TlpWeekly.Name = "TlpWeekly";
			this.TlpWeekly.RowCount = 2;
			this.TlpWeekly.RowStyles.Add(new System.Windows.Forms.RowStyle());
			this.TlpWeekly.RowStyles.Add(new System.Windows.Forms.RowStyle());
			this.TlpWeekly.Size = new System.Drawing.Size(153, 34);
			this.TlpWeekly.TabIndex = 25;
			this.TlpWeekly.Visible = false;
			// 
			// CkbSunday
			// 
			this.CkbSunday.AutoSize = true;
			this.CkbSunday.Location = new System.Drawing.Point(133, 16);
			this.CkbSunday.Name = "CkbSunday";
			this.CkbSunday.Size = new System.Drawing.Size(15, 14);
			this.CkbSunday.TabIndex = 26;
			this.CkbSunday.UseVisualStyleBackColor = true;
			// 
			// CkbSaturday
			// 
			this.CkbSaturday.AutoSize = true;
			this.CkbSaturday.Location = new System.Drawing.Point(112, 16);
			this.CkbSaturday.Name = "CkbSaturday";
			this.CkbSaturday.Size = new System.Drawing.Size(15, 14);
			this.CkbSaturday.TabIndex = 25;
			this.CkbSaturday.UseVisualStyleBackColor = true;
			// 
			// CkbFriday
			// 
			this.CkbFriday.AutoSize = true;
			this.CkbFriday.Location = new System.Drawing.Point(91, 16);
			this.CkbFriday.Name = "CkbFriday";
			this.CkbFriday.Size = new System.Drawing.Size(15, 14);
			this.CkbFriday.TabIndex = 24;
			this.CkbFriday.UseVisualStyleBackColor = true;
			// 
			// CkbThursday
			// 
			this.CkbThursday.AutoSize = true;
			this.CkbThursday.Location = new System.Drawing.Point(70, 16);
			this.CkbThursday.Name = "CkbThursday";
			this.CkbThursday.Size = new System.Drawing.Size(15, 14);
			this.CkbThursday.TabIndex = 23;
			this.CkbThursday.UseVisualStyleBackColor = true;
			// 
			// CkbWednesday
			// 
			this.CkbWednesday.AutoSize = true;
			this.CkbWednesday.Location = new System.Drawing.Point(46, 16);
			this.CkbWednesday.Name = "CkbWednesday";
			this.CkbWednesday.Size = new System.Drawing.Size(15, 14);
			this.CkbWednesday.TabIndex = 22;
			this.CkbWednesday.UseVisualStyleBackColor = true;
			// 
			// CkbTuesday
			// 
			this.CkbTuesday.AutoSize = true;
			this.CkbTuesday.Location = new System.Drawing.Point(25, 16);
			this.CkbTuesday.Name = "CkbTuesday";
			this.CkbTuesday.Size = new System.Drawing.Size(15, 14);
			this.CkbTuesday.TabIndex = 21;
			this.CkbTuesday.UseVisualStyleBackColor = true;
			// 
			// CkbMonday
			// 
			this.CkbMonday.AutoSize = true;
			this.CkbMonday.Location = new System.Drawing.Point(3, 16);
			this.CkbMonday.Name = "CkbMonday";
			this.CkbMonday.Size = new System.Drawing.Size(15, 14);
			this.CkbMonday.TabIndex = 14;
			this.CkbMonday.UseVisualStyleBackColor = true;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(133, 0);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(14, 13);
			this.label13.TabIndex = 20;
			this.label13.Text = "S";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(112, 0);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(14, 13);
			this.label12.TabIndex = 19;
			this.label12.Text = "S";
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(91, 0);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(13, 13);
			this.label11.TabIndex = 18;
			this.label11.Text = "F";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(70, 0);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(14, 13);
			this.label10.TabIndex = 17;
			this.label10.Text = "T";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(46, 0);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(18, 13);
			this.label9.TabIndex = 16;
			this.label9.Text = "W";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(25, 0);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(14, 13);
			this.label8.TabIndex = 15;
			this.label8.Text = "T";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(3, 0);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(16, 13);
			this.label7.TabIndex = 14;
			this.label7.Text = "M";
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.Location = new System.Drawing.Point(64, 172);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(186, 20);
			this.dateTimePicker1.TabIndex = 24;
			// 
			// CbReoccur
			// 
			this.CbReoccur.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.CbReoccur.FormattingEnabled = true;
			this.CbReoccur.Items.AddRange(new object[] {
            "Doesnt",
            "Daily",
            "Weekly"});
			this.CbReoccur.Location = new System.Drawing.Point(77, 105);
			this.CbReoccur.Name = "CbReoccur";
			this.CbReoccur.Size = new System.Drawing.Size(114, 21);
			this.CbReoccur.TabIndex = 23;
			this.CbReoccur.SelectedIndexChanged += new System.EventHandler(this.CbReoccur_SelectedIndexChanged);
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(23, 178);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(30, 13);
			this.label6.TabIndex = 22;
			this.label6.Text = "Date";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(23, 108);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(48, 13);
			this.label5.TabIndex = 21;
			this.label5.Text = "Reoccur";
			// 
			// CbPriority
			// 
			this.CbPriority.DisplayMember = "1";
			this.CbPriority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.CbPriority.FormattingEnabled = true;
			this.CbPriority.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
			this.CbPriority.Location = new System.Drawing.Point(67, 78);
			this.CbPriority.Name = "CbPriority";
			this.CbPriority.Size = new System.Drawing.Size(124, 21);
			this.CbPriority.TabIndex = 19;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(23, 82);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(38, 13);
			this.label3.TabIndex = 18;
			this.label3.Text = "Priority";
			// 
			// NudTimeToComplete
			// 
			this.NudTimeToComplete.Location = new System.Drawing.Point(122, 52);
			this.NudTimeToComplete.Name = "NudTimeToComplete";
			this.NudTimeToComplete.Size = new System.Drawing.Size(69, 20);
			this.NudTimeToComplete.TabIndex = 17;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(23, 54);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(93, 13);
			this.label2.TabIndex = 16;
			this.label2.Text = "Time To Complete";
			// 
			// TbName
			// 
			this.TbName.Location = new System.Drawing.Point(64, 26);
			this.TbName.Name = "TbName";
			this.TbName.Size = new System.Drawing.Size(127, 20);
			this.TbName.TabIndex = 15;
			// 
			// LbName
			// 
			this.LbName.AutoSize = true;
			this.LbName.Location = new System.Drawing.Point(23, 29);
			this.LbName.Name = "LbName";
			this.LbName.Size = new System.Drawing.Size(35, 13);
			this.LbName.TabIndex = 14;
			this.LbName.Text = "Name";
			// 
			// CbSub
			// 
			this.CbSub.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.CbSub.FormattingEnabled = true;
			this.CbSub.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
			this.CbSub.Location = new System.Drawing.Point(223, 78);
			this.CbSub.Name = "CbSub";
			this.CbSub.Size = new System.Drawing.Size(86, 21);
			this.CbSub.TabIndex = 26;
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(191, 81);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(26, 13);
			this.label14.TabIndex = 27;
			this.label14.Text = "Sub";
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox1.Controls.Add(this.button2);
			this.groupBox1.Controls.Add(this.btnSave);
			this.groupBox1.Controls.Add(this.TbName);
			this.groupBox1.Controls.Add(this.dateTimePicker1);
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.label14);
			this.groupBox1.Controls.Add(this.LbName);
			this.groupBox1.Controls.Add(this.CbSub);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.TlpWeekly);
			this.groupBox1.Controls.Add(this.NudTimeToComplete);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.CbReoccur);
			this.groupBox1.Controls.Add(this.CbPriority);
			this.groupBox1.Controls.Add(this.label5);
			this.groupBox1.Location = new System.Drawing.Point(347, 12);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(324, 252);
			this.groupBox1.TabIndex = 28;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "groupBox1";
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(6, 223);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(75, 23);
			this.button2.TabIndex = 29;
			this.button2.Text = "Delete";
			this.button2.UseVisualStyleBackColor = true;
			// 
			// btnSave
			// 
			this.btnSave.Location = new System.Drawing.Point(243, 223);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(75, 23);
			this.btnSave.TabIndex = 29;
			this.btnSave.Text = "Save";
			this.btnSave.UseVisualStyleBackColor = true;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// btnAdd
			// 
			this.btnAdd.Location = new System.Drawing.Point(12, 390);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new System.Drawing.Size(75, 23);
			this.btnAdd.TabIndex = 29;
			this.btnAdd.Text = "Add";
			this.btnAdd.UseVisualStyleBackColor = true;
			this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
			// 
			// Form2
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(683, 425);
			this.Controls.Add(this.btnAdd);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.btnDone);
			this.Name = "Form2";
			this.Text = "Form2";
			this.Load += new System.EventHandler(this.Form2_Load);
			this.TlpWeekly.ResumeLayout(false);
			this.TlpWeekly.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.NudTimeToComplete)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button btnDone;
		private System.Windows.Forms.TableLayoutPanel TlpWeekly;
		private System.Windows.Forms.CheckBox CkbSunday;
		private System.Windows.Forms.CheckBox CkbSaturday;
		private System.Windows.Forms.CheckBox CkbFriday;
		private System.Windows.Forms.CheckBox CkbThursday;
		private System.Windows.Forms.CheckBox CkbWednesday;
		private System.Windows.Forms.CheckBox CkbTuesday;
		private System.Windows.Forms.CheckBox CkbMonday;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.ComboBox CbReoccur;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.ComboBox CbPriority;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.NumericUpDown NudTimeToComplete;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox TbName;
		private System.Windows.Forms.Label LbName;
		private System.Windows.Forms.ComboBox CbSub;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.Button btnAdd;
	}
}