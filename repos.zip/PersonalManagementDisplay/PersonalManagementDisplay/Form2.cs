﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace PersonalManagementDisplay
{
	public partial class Form2 : Form
	{
		string jsonText;
		Routine routine;
		JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
		{
			NullValueHandling = NullValueHandling.Ignore,
			MissingMemberHandling = MissingMemberHandling.Ignore
		};
		int indexHighlighted;

		TableLayoutPanel tlpItems = new TableLayoutPanel();
		public Button[] btnItems;
		public CheckBox[] ckbItems;


		public Form2()
		{
			InitializeComponent();
		}

		private void Form2_Load(object sender, EventArgs e)
		{
			//routine
			jsonText = System.IO.File.ReadAllText(@"C:\Users\PC\Documents\test_folder\RoutinejsonTest.txt");
			routine = JsonConvert.DeserializeObject<Routine>(jsonText, jsonSerializerSettings);

			TLPItemsCreate();
		}

		public int routineTaskCount()
		{
			int taskCount = 0;
			foreach (var item in routine.RoutineItem)
			{
				if (item.enabled)
				{
					if (item.Time.boolReoccur)
					{
						if (item.Time.reoccur == "Daily")
						{
							taskCount += 1;
						}
						else if (item.Time.reoccur == "Weekly")
						{
							for (int i = 0; i < 7; i++)
							{
								if ((item.Time.Days[i] == true) & (i == ((int)(System.DateTime.Now.DayOfWeek + 6) % 7)))
								{
									taskCount += 1;
								}
							}
						}
						else if (item.Time.reoccur == "Doesnt")
						{
							//
						}
					}
				}
			}
			return taskCount;
		}

		private void TLPItemsCreate()
		{
			//int taskCount = routineTaskCount();
			btnItems = new Button[routine.RoutineItem.Length];
			ckbItems = new CheckBox[routine.RoutineItem.Length];

			string labelFont = "Transcript";
			int labelFontSize = 14;

			tlpItems.Location = new System.Drawing.Point(5, 5);
			tlpItems.Name = "tlpItems1";
			tlpItems.Size = new System.Drawing.Size(50, 50);
			tlpItems.AutoSize = true;
			tlpItems.MaximumSize = new Size(300,350);
			tlpItems.AutoScroll = true;
			tlpItems.BackColor = Color.FromArgb(255, 32, 32, 32);
			tlpItems.ForeColor = Color.FromArgb(255, 255, 130, 0);
			tlpItems.Margin = new Padding(5);
			tlpItems.Padding = new Padding(5);
			tlpItems.Font = new Font(labelFont, labelFontSize);

			tlpItems.ColumnCount = 2;
			tlpItems.RowCount = routine.RoutineItem.Length;

			//create colomns
			tlpItems.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 95F));
			tlpItems.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 5F));
			//create rows
			for (int j = 0; j < tlpItems.RowCount; j++)
			{
				tlpItems.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
			}

			//create buttons and checkboxes
			
			for (int j = 0; j < tlpItems.RowCount; j++)
				{
				btnItems[j] = new Button
					{
						//Location = new Point(0, 0),
						Text = routine.RoutineItem[j].text,
						Name = j.ToString(),
						Size = new Size(500, 30),
						//AutoSize = true,
						Dock = DockStyle.Fill,
						Margin = new Padding(0,0,50,0),
						//Padding = new Padding(0),
						//ImageAlign = ContentAlignment.MiddleCenter,
						//TextAlign = ContentAlignment.MiddleLeft,
						Anchor = (AnchorStyles.Left | AnchorStyles.Top),
						FlatStyle = FlatStyle.Flat
					};
				ckbItems[j] = new CheckBox
					{
						Text = "",
						Name = j.ToString(),
						AutoSize = true,
						Checked = routine.RoutineItem[j].enabled,
						Dock = DockStyle.Fill,
						Margin = new Padding(0),
						ImageAlign = ContentAlignment.MiddleCenter,
						Anchor = (AnchorStyles.Right),
						//FlatStyle = FlatStyle.Flat
					};
				btnItems[j].Click += new EventHandler(ButtonClick);
				ckbItems[j].Click += new EventHandler(CheckBoxClick);
				tlpItems.Controls.Add(btnItems[j], 0, j + 0);
				tlpItems.Controls.Add(ckbItems[j], 1, j + 0);
				}

			Controls.Add(tlpItems);
			//tlpItemsRefresh();
		}

		private void ButtonClick(object sender, EventArgs e)
		{
			indexHighlighted = Int32.Parse(((Button)(sender)).Name);
			int tempInt = Int32.Parse(((Button)(sender)).Name);
			TbName.Text = routine.RoutineItem[tempInt].text;
			NudTimeToComplete.Value = routine.RoutineItem[tempInt].timeToComplete;
			CbPriority.Text = routine.RoutineItem[tempInt].priority.ToString();
			CbSub.Text = routine.RoutineItem[tempInt].sub.ToString();
			CbReoccur.Text = routine.RoutineItem[tempInt].Time.reoccur;
			if (CbReoccur.Text == "Weekly")
			{
				TlpWeekly.Visible = true;
			}
			else { TlpWeekly.Visible = false; }


			//MessageBox.Show("You clicked on " + ((Button)(sender)).Name);
		}

		private void CheckBoxClick(object sender, EventArgs e)
		{
			int tempInt = Int32.Parse(((CheckBox)(sender)).Name);

			if (((CheckBox)(sender)).Checked == true)
			{
				((CheckBox)(sender)).Checked = true;
				routine.RoutineItem[tempInt].enabled = true;
			}
			else if (((CheckBox)(sender)).Checked == false)
			{
				((CheckBox)(sender)).Checked = false;
				routine.RoutineItem[tempInt].enabled = false;
			}
			//MessageBox.Show(routine.RoutineItem[tempInt].enabled.ToString());
		}

		private void btnSave_Click(object sender, EventArgs e)
		{
			btnItems[indexHighlighted].Text = TbName.Text;
			//assign Data to routine
			routine.RoutineItem[indexHighlighted].text = TbName.Text;
			routine.RoutineItem[indexHighlighted].timeToComplete = Convert.ToInt32(NudTimeToComplete.Value);
			routine.RoutineItem[indexHighlighted].priority = Int32.Parse(CbPriority.Text);
			routine.RoutineItem[indexHighlighted].sub = Int32.Parse(CbSub.Text);
			routine.RoutineItem[indexHighlighted].Time.reoccur = CbReoccur.Text;
			if (routine.RoutineItem[indexHighlighted].Time.reoccur == "Weekly")
			{
				routine.RoutineItem[indexHighlighted].Time.Days[0] = CkbMonday.Checked;
				routine.RoutineItem[indexHighlighted].Time.Days[1] = CkbTuesday.Checked;
				routine.RoutineItem[indexHighlighted].Time.Days[2] = CkbWednesday.Checked;
				routine.RoutineItem[indexHighlighted].Time.Days[3] = CkbThursday.Checked;
				routine.RoutineItem[indexHighlighted].Time.Days[4] = CkbFriday.Checked;
				routine.RoutineItem[indexHighlighted].Time.Days[5] = CkbSaturday.Checked;
				routine.RoutineItem[indexHighlighted].Time.Days[6] = CkbSunday.Checked;
			}





			JsonSerializer serializer = new JsonSerializer();
			serializer.NullValueHandling = NullValueHandling.Ignore;
		
			using(StreamWriter sw = new StreamWriter(@"C:\Users\PC\Documents\test_folder\routineJsonTest.txt"))
			using(JsonWriter writer = new JsonTextWriter(sw))
			{
				serializer.Serialize(writer, routine);
				
			}
		}

		private void btnDone_Click(object sender, EventArgs e)
		{
			JsonSerializer serializer = new JsonSerializer();
			serializer.NullValueHandling = NullValueHandling.Ignore;

			using (StreamWriter sw = new StreamWriter(@"C:\Users\PC\Documents\test_folder\routineJsonTest.txt"))
			using (JsonWriter writer = new JsonTextWriter(sw))
			{
				serializer.Serialize(writer, routine);

			}
			this.Close();
		}

		private void CbReoccur_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (CbReoccur.Text == "Daily")
			{
				TlpWeekly.Visible = false;
			}
			else if (CbReoccur.Text == "Weekly")
			{
				TlpWeekly.Visible = true;
			}
			else
			{
				TlpWeekly.Visible = false;
			}
		}

		private void btnAdd_Click(object sender, EventArgs e)
		{
			MessageBox.Show(routine.RoutineItem.Length.ToString());

			Button tempButton = new Button
			{
				//Location = new Point(0, 0),
				Text = "Hello", //routine.RoutineItem[j].text,
				Name = Name = (routine.RoutineItem.Length + 1).ToString(),
				Size = new Size(50, 40),
				//AutoSize = true,
				Dock = DockStyle.Fill,
				Margin = new Padding(0, 0, 50, 0),
				//Padding = new Padding(0),
				//ImageAlign = ContentAlignment.MiddleCenter,
				//TextAlign = ContentAlignment.MiddleLeft,
				Anchor = (AnchorStyles.Left | AnchorStyles.Top),
				FlatStyle = FlatStyle.Flat
			};
			CheckBox tempCheckBox = new CheckBox
			{
				Text = "",
				Name = (routine.RoutineItem.Length +1).ToString(),
				AutoSize = true,
				Checked = false, //routine.RoutineItem[j].enabled,
				Dock = DockStyle.Fill,
				Margin = new Padding(0),
				ImageAlign = ContentAlignment.MiddleCenter,
				Anchor = (AnchorStyles.Right),
				//FlatStyle = FlatStyle.Flat
			};
			tlpItems.Controls.Add(tempButton, 0, btnItems.Length + 1 + 0);
			tlpItems.Controls.Add(tempCheckBox, 1, btnItems.Length + 1 + 0);


			/*JObject rss = JObject.Parse(jsonText);
			JArray channel = (JArray)rss["RoutineItem"];
			channel.Add("text","Hello");
			channel.Add(new JProperty("enabled", true));
			channel.Add(new JProperty("timeToComplete", 10));
			channel.Add(new JProperty("priority", 2));
			channel.Add(new JProperty("sub", 2));
			//channel.Add(new JProperty("Time",JArray);
			*/
			JsonSerializer serializer = new JsonSerializer();
			serializer.NullValueHandling = NullValueHandling.Ignore;

			using (StreamWriter sw = new StreamWriter(@"C:\Users\PC\Documents\test_folder\routineJsonTest.txt"))
			using (JsonWriter writer = new JsonTextWriter(sw))
			{
				serializer.Serialize(writer, routine);

			}

		}
	}
}
