﻿
public class Routine
{
	public Routineitem[] RoutineItem { get; set; }
}

public class Routineitem
{
	public string text { get; set; }
	public bool enabled { get; set; }
	public int timeToComplete { get; set; }
	public int priority { get; set; }
	public int sub { get; set; }
	public Time Time { get; set; }
}

public class Time
{
	public bool boolReoccur { get; set; }
	public string reoccur { get; set; }
	public int[] Date { get; set; }
	public bool[] Days { get; set; }
}
